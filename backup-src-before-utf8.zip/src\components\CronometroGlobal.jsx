// src/components/CronometroGlobal.jsx
import React from "react";
export default function CronometroGlobal({ className, style }) {
  return <div className={className} style={style}>[Cronómetro Global]</div>;
}
