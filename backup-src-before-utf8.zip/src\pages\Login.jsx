import React from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import {
  signInWithEmailAndPassword,
  fetchSignInMethodsForEmail,
} from "firebase/auth";
import { auth } from "../firebase";

export default function Login() {
  const nav = useNavigate();
  const loc = useLocation();
  const qs = new URLSearchParams(loc.search);

  const [email, setEmail] = React.useState(qs.get("email") || "");
  const [pass, setPass] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [canCreate, setCanCreate] = React.useState(false); // CTA a registro si no existe

  const goAfterLogin = () => {
    // Si venía con ?next=/algo, respétalo
    const next = qs.get("next");
    nav(next || "/inicio", { replace: true });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setCanCreate(false);

    if (!email.trim() || !pass) {
      setError("Ingresa tu correo y contraseña.");
      return;
    }

    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email.trim(), pass);
      goAfterLogin();
    } catch (err) {
      // ¿correo no existe? -> ofrece crear cuenta
      if (err?.code === "auth/user-not-found") {
        try {
          const methods = await fetchSignInMethodsForEmail(auth, email.trim());
          if (!methods || methods.length === 0) {
            setCanCreate(true);
            setError(
              "No encontramos una cuenta con ese correo. Puedes crearla ahora."
            );
          } else {
            setError("Tu cuenta existe, pero la contraseña no coincide.");
          }
        } catch (e2) {
          setError(e2?.message || "No pudimos verificar el correo.");
        }
      } else if (err?.code === "auth/invalid-credential") {
        setError("Correo o contraseña inválidos.");
      } else {
        setError(err?.message || "No se pudo iniciar sesión.");
      }
    } finally {
      setLoading(false);
    }
  };

  const goToRegister = () => {
    const url = new URLSearchParams();
    if (email) url.set("email", email.trim());
    if (qs.get("next")) url.set("next", qs.get("next"));
    nav(`/registro?${url.toString()}`);
  };

  return (
    <div style={styles.wrap}>
      <div style={styles.card}>
        <h1 style={styles.h1}>🔐 Iniciar Sesión</h1>

        <form onSubmit={handleSubmit} style={{ display: "grid", gap: 10 }}>
          <label style={styles.label}>Correo electrónico</label>
          <input
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ejemplo@correo.com"
            style={styles.input}
          />

          <label style={styles.label}>Contraseña</label>
          <input
            type="password"
            autoComplete="current-password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            placeholder="Tu clave secreta"
            style={styles.input}
          />

          {error && <div style={styles.error}>{error}</div>}

          <button type="submit" disabled={loading} style={styles.btnPrimary}>
            {loading ? "Ingresando…" : "Ingresar"}
          </button>
        </form>

        {/* CTA siempre visible */}
        <div style={styles.muted}>
          ¿No tienes cuenta?{" "}
          <button onClick={goToRegister} style={styles.linkBtn}>
            Regístrate aquí
          </button>
        </div>

        {/* CTA extra cuando el correo no existe */}
        {canCreate && (
          <div style={{ marginTop: 8 }}>
            <button onClick={goToRegister} style={styles.btnGhost}>
              Crear cuenta con <b>{email}</b>
            </button>
          </div>
        )}

        <div style={{ marginTop: 8 }}>
          <Link to="/" style={styles.link}>
            ⬅ Volver al inicio
          </Link>
        </div>
      </div>
    </div>
  );
}

const styles = {
  wrap: {
    minHeight: "100dvh",
    display: "grid",
    placeItems: "center",
    background:
      "radial-gradient(1200px 600px at 20% -10%, #7dd3fc22, transparent), radial-gradient(1000px 500px at 110% 10%, #a7f3d022, transparent), #f8fafc",
    padding: 16,
  },
  card: {
    width: "100%",
    maxWidth: 460,
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    padding: 24,
    boxShadow: "0 10px 30px rgba(2,6,23,.08)",
  },
  h1: { margin: 0, marginBottom: 10, fontSize: 22 },
  label: { fontSize: 13, color: "#334155" },
  input: {
    padding: "10px 12px",
    border: "1px solid #cbd5e1",
    borderRadius: 8,
    outline: "none",
  },
  btnPrimary: {
    marginTop: 6,
    padding: "10px 12px",
    borderRadius: 8,
    border: "none",
    background: "#0ea5e9",
    color: "#fff",
    cursor: "pointer",
  },
  btnGhost: {
    padding: "8px 10px",
    borderRadius: 8,
    border: "1px solid #94a3b8",
    background: "#fff",
    cursor: "pointer",
  },
  muted: { marginTop: 12, fontSize: 13, color: "#475569" },
  link: { color: "#0ea5e9", textDecoration: "none" },
  linkBtn: {
    background: "transparent",
    color: "#0ea5e9",
    border: "none",
    cursor: "pointer",
    padding: 0,
  },
  error: {
    background: "#fef2f2",
    color: "#b91c1c",
    border: "1px solid #fecaca",
    padding: "8px 10px",
    borderRadius: 8,
    fontSize: 13,
  },
};
