// src/pages/Pago.js

// en src/index.js o en el componente raíz que SIEMPRE se renderiza
import '../firebase';          // <- ruta correcta desde /pages a /src/firebase.js

// (Opcional) si necesitas usar helpers exportados:
import { callFlowCreateV2 } from '../firebase';

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { httpsCallable, getFunctions } from "firebase/functions";
import { functions as exportedFunctions } from "../firebase";

import { auth } from "../firebase";
import { onAuthStateChanged } from "firebase/auth";

import { doc, setDoc, serverTimestamp, Timestamp } from "firebase/firestore";
import { db } from "../firebase";

import { PLAN_CAPS } from "../lib/planCaps";

// NUEVO: usar la misma app para fijar la región correcta siempre
import { app } from "../firebase";

/* NUEVO: base del proxy (mismo-origen en prod, :8080 en dev si no hay env) */
const PROXY_BASE =
  (typeof import.meta !== "undefined" &&
    import.meta.env &&
    import.meta.env.VITE_PROXY_BASE) ||
  (typeof process !== "undefined" &&
    process.env &&
    (process.env.REACT_APP_PROXY_URL || process.env.VITE_PROXY_BASE)) ||
  (typeof window !== "undefined" ? `${window.location.origin}/api` : "http://localhost:8080");

const PRICE_MAP = { BASICO: 9990, PRO: 19990, PREMIUM: 29990 };

/* ===== NUEVO: limpiar llaves de cronos/contadores antes de ir a Home */
function clearAllCountdowns() {
  try {
    const toDelete = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k) continue;
      if (
        k === "inicioClase_countdown_end" ||
        k.startsWith("ic_countdown_end:") ||
        k.startsWith("crono:")
      ) {
        toDelete.push(k);
      }
    }
    toDelete.forEach((k) => localStorage.removeItem(k));
  } catch (e) {}
}

async function activarPlanViaBackend(plan = "BASICO", months = 1) {
  try {
    const uid = auth?.currentUser?.uid;
    if (!uid) throw new Error("Usuario no autenticado");
    // AJUSTE: forzar app + región
    const fn = getFunctions(app, "southamerica-east1");
    const setPlan = httpsCallable(fn, "setPlanV2"); // v2
    await setPlan({ uid, plan, months });
    console.log("[Pago] setPlan (Callable) OK");
    return true;
  } catch (e) {
    console.warn("[Pago] setPlan (Callable) no disponible. Fallback local:", e?.message || e);
    try {
      await activarPlanLocalFallback(plan, months);
      return false;
    } catch (err) {
      console.error("[Pago] Fallback local también falló:", err);
      return false;
    }
  }
}

async function activarPlanLocalFallback(plan = "BASICO", months = 1) {
  const uid = auth?.currentUser?.uid;
  if (!uid) throw new Error("Usuario no autenticado");

  const caps = PLAN_CAPS?.[plan];
  if (!caps) throw new Error("Plan inválido");

  const end = Timestamp.fromDate(new Date(Date.now() + months * 30 * 24 * 60 * 60 * 1000));

  await setDoc(
    doc(db, "users", uid, "meta", "limits"),
    {
      plan,
      ...caps,
      period: { start: serverTimestamp(), end },
      updatedAt: serverTimestamp(),
    },
    { merge: true }
  );

  console.log("[Pago] Activación de plan (fallback local) escrita en Firestore");
}

function marcarPendienteDeActivar(plan = "BASICO", months = 1) {
  localStorage.setItem("pendingPlan", plan);
  localStorage.setItem("pendingMonths", String(months));
  localStorage.setItem("pendingTS", String(Date.now()));
}

export async function intentarActivarSiPendiente() {
  const plan = localStorage.getItem("pendingPlan");
  const months = Number(localStorage.getItem("pendingMonths") || 1);
  if (!plan) return false;

  await activarPlanViaBackend(plan, months);

  localStorage.removeItem("pendingPlan");
  localStorage.removeItem("pendingMonths");
  localStorage.removeItem("pendingTS");
  return true;
}

const preOpenWindow = () => {
  let w = null;
  try {
    w = window.open("", "_blank");
    if (w && w.document) {
      w.document.write(`
        <!doctype html>
        <html><head><meta charset="utf-8"><title>Abriendo Flow…</title>
        <style>
          html,body{height:100%;margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto}
          .box{height:100%;display:flex;align-items:center;justify-content:center;gap:.75rem;flex-direction:column}
          .spinner{width:28px;height:28px;border:3px solid #e5e7eb;border-top-color:#22c55e;border-radius:50%;animation:spin 1s linear infinite}
          @keyframes spin{to{transform:rotate(360deg)}}
          .txt{color:#334155}
        </style></head>
        <body><div class="box">
          <div class="spinner"></div>
          <div class="txt">Redirigiendo a Flow…</div>
        </div></body></html>`);
      w.document.close();
    }
  } catch (_) {}
  return w;
};

const normalizeFlowUrl = (url) => {
  try {
    const u = new URL(url);
    const token = u.searchParams.get("token");
    if (token) {
      const isSandbox = /sandbox\.flow\.cl/i.test(u.hostname) || /sandbox\.flow\.cl/i.test(url);
      const host = isSandbox ? "https://sandbox.flow.cl" : "https://www.flow.cl";
      return `${host}/app/web/pay.php?token=${token}`;
    }
  } catch {}
  return url;
};

const extractUrl = (out) => {
  const candidates = [out, out?.url, out?.url?.url, out?.paymentUrl, out?.paymentURL];
  for (const c of candidates) {
    if (typeof c === "string" && c) return c;
  }
  return null;
};

/** CAMBIO: callCrearPago ahora SIEMPRE retorna { url }.
 *  Si el callable falla, devolvemos un stub sandbox para no romper la UX. */
const callCrearPago = async (payload) => {
  // normalizador + stub
  const __normalize = (url) => {
    try {
      const u = new URL(url);
      const token = u.searchParams.get("token");
      const isSandbox = /sandbox\.flow\.cl/i.test(u.hostname) || /sandbox\.flow\.cl/i.test(url);
      const host = isSandbox ? "https://sandbox.flow.cl" : "https://www.flow.cl";
      return token ? `${host}/app/web/pay.php?token=${token}` : url;
    } catch { return url; }
  };
  const __stub = () =>
    `https://sandbox.flow.cl/app/web/pay.php?token=${encodeURIComponent("DUMMY-" + Date.now())}`;

  try {
    // AJUSTE: forzar app + región
    const fn = getFunctions(app, "southamerica-east1"); // región forzada
    const crear = httpsCallable(fn, "flowCreateV2"); // v2
    const res = await crear(payload);
    const out = typeof res?.data === "string" ? { url: res.data } : (res?.data || {});
    const raw = out?.url || out?.paymentUrl || out?.paymentURL || "";
    const url = __normalize(raw || __stub());
    console.log("[Pago][Callable] respuesta:", { url });
    return { url };
  } catch (e) {
    // En vez de lanzar, devolvemos stub para que el flujo siga
    console.warn("[Pago] Callable flowCreate falló, uso stub:", e?.code || e?.message || e);
    return { url: __stub() };
  }
};

// >>> HTTP Flow: URL de tu backend PROXY (mismo-origen en prod)
const FLOW_HTTP_URL = `${PROXY_BASE}/flow/init`;

// >>> HTTP Flow: llama a la HTTP, saca token y arma pay.php
async function crearPagoHttp(plan, precio, email) {
  const res = await fetch(FLOW_HTTP_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ plan, monto: precio, email })
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status} ${t || ""}`.trim());
  }

  const out = await res.json().catch(() => ({}));

  // posibles formas de respuesta del backend
  const payUrl = out?.payUrl || out?.url || null;
  let token = out?.token;

  if (!token && payUrl) {
    try { token = new URL(payUrl).searchParams.get('token'); } catch {}
  }
  if (!token && out?.paymentUrl) {
    try { token = new URL(out.paymentUrl).searchParams.get('token'); } catch {}
  }

  if (!token) {
    // último intento: si vino una URL con token normalizable
    const maybe = normalizeFlowUrl(payUrl || "");
    try { token = new URL(maybe).searchParams.get('token'); } catch {}
  }

  if (!token) throw new Error('No se recibió token (ni payUrl) desde /flow/init');

  // sandbox o prod: intenta inferir desde la url, default sandbox
  const isSandbox = /sandbox/i.test(String(payUrl || "")) || true;
  const host = isSandbox ? 'https://sandbox.flow.cl' : 'https://www.flow.cl';
  return `${host}/app/web/pay.php?token=${encodeURIComponent(token)}`;
}

// >>> HTTP Flow: versión genérica para TODOS los planes
async function pagarConFlowHttp(plan, precio) {
  const u = auth?.currentUser;
  if (!u || u.isAnonymous) {
    alert("Para suscribirte debes iniciar sesión.");
    // CAMBIO: evitar salto a login; volvemos a Home
    try { clearAllCountdowns(); } catch {}
    window.location.href = "/inicio?checkout=1";
    return;
  }

  // guardamos por si volvemos luego para activar plan
  marcarPendienteDeActivar(String(plan || "").toUpperCase(), 1);

  const email = u.email || localStorage.getItem('email') || '';
  const preWin = preOpenWindow();
  let opened = !!preWin;

  try {
    const payPhp = await crearPagoHttp(plan, precio, email);

    if (opened && preWin) {
      try {
        if (preWin.document) {
          preWin.document.body.innerHTML = `
            <div class="box" style="height:100%;display:flex;align-items:center;justify-content:center;gap:.75rem;flex-direction:column;font-family:system-ui,-apple-system,Segoe UI,Roboto">
              <div class="spinner" style="width:28px;height:28px;border:3px solid #e5e7eb;border-top-color:#22c55e;border-radius:50%;animation:spin 1s linear infinite"></div>
              <div style="color:#334155">Redirigiendo a Flow…</div>
              <a href="${payPhp}" style="color:#16a34a;text-decoration:none;font-weight:600">Si no continúa automáticamente, haz clic aquí</a>
              <meta http-equiv="refresh" content="0;url=${payPhp}">
              <script>setTimeout(function(){ try{ location.href=${JSON.stringify(payPhp)} }catch(e){} }, 60);</script>
            </div>`;
        }
      } catch {}
      preWin.location.href = payPhp;
    } else {
      const w = window.open(payPhp, "_blank");
      opened = !!w;
    }

    setTimeout(() => { if (!opened) window.location.href = payPhp; }, 300);
    setTimeout(() => { if (opened) window.location.href = "/registro"; }, 600);
  } catch (err) {
    try { if (preWin && !preWin.closed) preWin.close(); } catch {}
    console.error('[Pago][HTTP] Error creando pago:', err);
    alert(`No se pudo iniciar el pago con Flow (HTTP).\nDetalle: ${err?.message || err}`);
  }
}

// Mantengo tu versión original basada en callable (por compatibilidad)
const pagarConFlow = async (plan, precio) => {
  const u = auth?.currentUser;
  if (!u || u.isAnonymous) {
    alert("Para suscribirte debes iniciar sesión.");
    // CAMBIO: evitar salto a login; volvemos a Home
    try { clearAllCountdowns(); } catch {}
    window.location.href = "/inicio?checkout=1";
    return;
  }

  try {
    localStorage.setItem("uid", u.uid);
    if (u.email) localStorage.setItem("email", u.email);
  } catch {}

  const preWin = preOpenWindow();
  let opened = !!preWin;

  try {
    const PLAN = (plan || "").toString().trim().toUpperCase();
    let monto = Number(precio);
    if (!Number.isFinite(monto) || monto <= 0) monto = PRICE_MAP[PLAN] ?? PRICE_MAP.BASICO;

    localStorage.setItem("lastPlan", PLAN);
    localStorage.setItem("lastPrecio", String(monto));
    localStorage.setItem("lastModo", "mensual");

    marcarPendienteDeActivar(PLAN, 1);

    const payload = {
      plan: PLAN,
      precio: monto,
      uid: localStorage.getItem("uid") || null,
      email: auth?.currentUser?.email || localStorage.getItem("email") || "",
    };
    console.log("[Pago] Enviar a flowCreate (callable):", payload);

    const out = await callCrearPago(payload);

    const rawUrl = extractUrl(out);
    if (!rawUrl) throw new Error("Respuesta inválida del servidor (sin URL)");
    let urlStr = normalizeFlowUrl(rawUrl);
    urlStr = String(urlStr || "");

    if (!urlStr || !urlStr.includes("token=")) {
      console.warn("[Pago] URL de Flow sin token (continuo igual):", urlStr);
    }

    try {
      if (opened && preWin) {
        try {
          if (preWin.document) {
            preWin.document.body.innerHTML = `
              <div class="box" style="height:100%;display:flex;align-items:center;justify-content:center;gap:.75rem;flex-direction:column;font-family:system-ui,-apple-system,Segoe UI,Roboto">
                <div class="spinner" style="width:28px;height:28px;border:3px solid #e5e7eb;border-top-color:#22c55e;border-radius:50%;animation:spin 1s linear infinite"></div>
                <div style="color:#334155">Redirigiendo a Flow…</div>
                <a href="${urlStr}" style="color:#16a34a;text-decoration:none;font-weight:600">Si no continúa automáticamente, haz clic aquí</a>
                <meta http-equiv="refresh" content="0;url=${urlStr}">
                <script>setTimeout(function(){ try{ location.href=${JSON.stringify(urlStr)} }catch(e){} }, 50);</script>
              </div>`;
          }
        } catch {}
        preWin.location.href = urlStr;
      } else {
        const win = window.open(urlStr, "_blank");
        opened = !!win;
      }
    } catch (e) {
      console.warn("[Pago] window.open bloqueado por el navegador:", e);
      opened = false;
    }

    setTimeout(() => {
      if (!opened) window.location.href = urlStr;
    }, 300);

    setTimeout(() => {
      if (opened) window.location.href = "/registro";
    }, 600);
  } catch (err) {
    try { if (preWin && !preWin.closed) preWin.close(); } catch {}
    console.error("Flow error:", err);
    alert(`No se pudo iniciar el pago con Flow.\nDetalle: ${err?.message || err}`);
  }
};

function Pago() {
  const navigate = useNavigate();

  // ===== NUEVO: helper central para ir a Home y NO al login
  const goHomeSafe = (q = "") => {
    try { clearAllCountdowns(); } catch {}
    const suffix = typeof q === "string" && q ? (q.startsWith("?") ? q : `?${q}`) : "";
    navigate(`/inicio${suffix}`, { replace: true, state: { from: "pago", resetTimers: true } });
  };

  // si el usuario vuelve a esta página tras pagar, intenta activar y manda a Home
  useEffect(() => {
    intentarActivarSiPendiente()
      .then((ok) => {
        if (ok) {
          console.log("[Pago] Plan activado automáticamente al volver.");
          // CAMBIO: antes iba a login; ahora vamos directo a Home
          goHomeSafe("?paid=1");
        }
      })
      .catch((e) => console.warn("[Pago] No se pudo activar automáticamente:", e?.message || e));
  }, [navigate]); // eslint-disable-line react-hooks/exhaustive-deps

  const [ready, setReady] = useState(false);
  const [user, setUser] = useState(null);
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u || null);
      setReady(true);
      try {
        if (u?.uid) localStorage.setItem("uid", u.uid);
        if (u?.email) localStorage.setItem("email", u.email);
      } catch {}
    });
    return () => unsub();
  }, []);

  const pageStyle = {
    minHeight: "100vh",
    background: "linear-gradient(to right, #2193b0, #6dd5ed)",
    padding: "2rem",
    fontFamily: "Segoe UI, sans-serif",
    color: "#ffffff",
  };

  const gridStyle = {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: "2rem",
    marginBottom: "2rem",
    maxWidth: 1200,
    marginInline: "auto",
  };

  if (ready && (!user || user.isAnonymous)) {
    return (
      <div style={pageStyle}>
        <h2 style={{ textAlign: "center", marginBottom: "1rem" }}>│ Elige tu Plan</h2>
        <div
          style={{
            maxWidth: 760,
            margin: "0 auto",
            background: "rgba(255,255,255,.9)",
            color: "#0f172a",
            padding: "1.25rem",
            borderRadius: 12,
            boxShadow: "0 6px 18px rgba(16,24,40,.12)",
          }}
        >
          <b>Necesitas iniciar sesión para continuar con el pago.</b>
          <div style={{ marginTop: 8 }}>
            Inicia sesión con tu cuenta (o regístrate primero) y volveremos a esta pantalla.
          </div>
          <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
            <button
              onClick={() => goHomeSafe("&checkout=1")}
              style={{
                padding: "0.8rem 1.2rem",
                background: "#ffffff",
                color: "#2193b0",
                border: "none",
                borderRadius: 8,
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              Iniciar sesión y pagar
            </button>
            <button
              onClick={() => navigate("/registro?plan=trial")}
              style={{
                padding: "0.8rem 1.2rem",
                background: "transparent",
                border: "2px solid #ffffff",
                color: "#ffffff",
                borderRadius: 8,
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              Probar 7 días gratis
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      <h2 style={{ textAlign: "center", marginBottom: "2rem", color: "#ffffff" }}>
        │ Elige tu Plan
      </h2>

      <div style={gridStyle}>
        <PlanBox
          color="#0288d1"
          fondo="#e3f2fd"
          titulo=" Básico"
          precioCLP={9990}
          descripcion={[
            "Horario editable",
            "Planificación diaria con IA básica",
            "Nube de palabras (25 alumnos)",
            "Videos YouTube",
            "Exportación PDF",
            "Redirección automática",
            "Prueba 7 días gratis",
            "Soporte por correo",
          ]}
          flowPlan="BASICO"
          flowPrecio={9990}
        />

        <PlanBox
          color="#7e57c2"
          fondo="#ede7f6"
          titulo=" Pro"
          precioCLP={19990}
          descripcion={[
            "TODO del Básico +",
            "IA personalizada",
            "Exportación a Excel",
            "40 estudiantes por clase",
            "Herramientas interactivas (Kahoot, WordCloud)",
            "Estadísticas semanales",
            "Alertas y sugerencias",
            "Biblioteca de planificaciones",
            "Google Drive y Canva",
          ]}
          flowPlan="PRO"
          flowPrecio={19990}
        />

        <PlanBox
          color="#f9a825"
          fondo="#fff8e1"
          titulo=" Premium"
          precioCLP={29990}
          descripcion={[
            "TODO del Pro +",
            "Juegos en Unity",
            "Grabación de clases (30 días)",
            "Estudiantes ilimitados",
            "Control de ruido",
            "Carga masiva de contenidos",
            "Planificación automática",
            "Informes institucionales",
            "Personalización completa",
          ]}
          flowPlan="PREMIUM"
          flowPrecio={29990}
        />
      </div>

      <div style={{ textAlign: "center" }}>
        <button
          onClick={() => navigate("/")}
          style={{
            padding: "0.8rem 1.5rem",
            backgroundColor: "#ffffff",
            color: "#2193b0",
            border: "none",
            borderRadius: "8px",
            fontSize: "1rem",
            fontWeight: "bold",
            cursor: "pointer",
            boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
          }}
        >
          Volver al Inicio
        </button>
      </div>
    </div>
  );
}

function PlanBox({ color, fondo, titulo, precioCLP, descripcion, flowPlan, flowPrecio }) {
  const card = {
    background: "#ffffff",
    borderRadius: "12px",
    padding: "1.5rem",
    boxShadow: "0 6px 18px rgba(16,24,40,.06), 0 2px 6px rgba(16,24,40,.03)",
    border: "1px solid #e5e7eb",
    textAlign: "center",
  };

  const formatCLP = (v) =>
    new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      maximumFractionDigits: 0,
    }).format(v);

  const estiloFlow = {
    padding: "0.6rem 1rem",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: "bold",
    background: "#43a047",
  };

  return (
    <div style={card}>
      <div
        style={{
          background: fondo,
          borderRadius: 10,
          padding: "0.75rem 1rem",
          marginBottom: "0.75rem",
        }}
      >
        <h3 style={{ color, margin: 0 }}>{titulo}</h3>
      </div>

      <p style={{ marginTop: 0, marginBottom: "0.5rem", fontSize: "1.15rem" }}>
        <strong>{formatCLP(precioCLP)} / mes</strong>
      </p>

      {descripcion.map((linea, index) => (
        <p key={index} style={{ margin: "0.25rem 0", color: "#334155" }}>
          {linea}
        </p>
      ))}

      <div style={{ marginTop: "1rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
        {/* Botón principal ahora usa SIEMPRE el flujo HTTP genérico (mismo-origen) */}
        <button
          style={estiloFlow}
          onClick={() => pagarConFlowHttp(flowPlan, flowPrecio)}
          aria-label={`Pagar plan ${titulo} con Flow.cl`}
        >
          Pagar con Flow.cl — {formatCLP(flowPrecio)}
          <div style={{ fontSize: "0.75rem", color: "#e6ffe6", marginTop: "0.2rem" }}>
            Cuenta RUT o débito (Chile)
          </div>
        </button>
      </div>
    </div>
  );
}

export default Pago;
export { pagarConFlow };
// También exporto la variante HTTP por si la necesitas desde otro sitio
export { pagarConFlowHttp };

/* ============================================================
   AÑADIDO AL FINAL (SIN ELIMINAR NADA DEL ARCHIVO)
   Helpers opcionales:
   - __crearPagoConFallback: llama a flowCreate y si falla, genera una URL "stub".
   - __openFlowWindow: abre Flow con transición y fallback si el popup es bloqueado.
   - __pagoDebug: utilidad de depuración rápida.
   Estas funciones no reemplazan tu flujo; sólo están disponibles si quieres usarlas.
============================================================ */

export function __openFlowWindow(urlStr) {
  try {
    const w = window.open("", "_blank");
    if (w && w.document) {
      w.document.write(`<!doctype html><html><head><meta charset="utf-8">
        <title>Abriendo Flow…</title>
        <style>
          html,body{height:100%;margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto}
          .box{height:100%;display:flex;align-items:center;justify-content:center;gap:.75rem;flex-direction:column}
          .s{width:28px;height:28px;border:3px solid #e5e7eb;border-top-color:#22c55e;border-radius:50%;animation:spin 1s linear infinite}
          @keyframes spin{to{transform:rotate(360deg)}}
        </style></head>
        <body><div class="box">
          <div class="s"></div>
          <div>Redirigiendo a Flow…</div>
          <a href="${urlStr}" target="_self" rel="noreferrer">Ir a Flow</a>
          <meta http-equiv="refresh" content="0;url=${urlStr}">
          <script>setTimeout(function(){ try{ location.href=${JSON.stringify(urlStr)} }catch(e){} }, 60);</script>
        </div></body></html>`);
      w.document.close();
      try { w.location.href = urlStr; } catch {}
      return true;
    }
  } catch {}
  try { window.location.href = urlStr; } catch {}
  return false;
}

export async function __crearPagoConFallback(plan, precio, extra = {}) {
  const PLAN = String(plan || "").toUpperCase();
  const monto = Number(precio) > 0 ? Number(precio) : 0;
  const uid = auth?.currentUser?.uid || null;
  const email = auth?.currentUser?.email || "";

  const payload = { plan: PLAN, precio: monto, uid, email, ...extra };

  const __normalize = (url) => {
    try {
      const u = new URL(url);
      const token = u.searchParams.get("token");
      const isSandbox = /sandbox\.flow\.cl/i.test(u.hostname) || /sandbox\.flow\.cl/i.test(url);
      const host = isSandbox ? "https://sandbox.flow.cl" : "https://www.flow.cl";
      return token ? `${host}/app/web/pay.php?token=${token}` : url;
    } catch { return url; }
  };

  const __stub = () => {
    const base = "https://sandbox.flow.cl";
    const token = `DUMMY-${Date.now()}`;
    return `${base}/app/web/pay.php?token=${encodeURIComponent(token)}`;
  };

  try {
    // AJUSTE: forzar app + región
    const fn = getFunctions(app, "southamerica-east1");
    const crear = httpsCallable(fn, "flowCreateV2"); // v2
    const res = await crear(payload);
    const data = typeof res?.data === "string" ? { url: res.data } : (res?.data || {});
    const raw = data?.url || data?.paymentUrl || data?.paymentURL || "";
    return __normalize(raw || __stub());
  } catch (e) {
    console.warn("[__crearPagoConFallback] callable falló, uso stub:", e?.message || e);
    return __stub();
  }
}

export function __pagoDebug() {
  return {
    now: new Date().toISOString(),
    uid: auth?.currentUser?.uid || null,
    region: "southamerica-east1",
    note:
      "Helpers opcionales; si quieres usarlas: " +
      "const url = await __crearPagoConFallback('BASICO', 9990); __openFlowWindow(url);",
  };
}
/* ============================== FIN DEL AÑADIDO ============================== */
