// App.jsx
import React from "react";
import { Suspense, lazy } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Outlet,
  useNavigate,
  useLocation,
} from "react-router-dom";

import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";
import { HashRouter as Router } from "react-router-dom";


// Páginas eager
import Home from "./pages/Home";
import Registro from "./pages/Registro";
import Login from "./pages/Login.jsx";
import Participa from "./pages/Participa";
import Perfil from "./pages/Perfil";
import HorarioEditable from "./pages/HorarioEditable";

// Guard
import PlanGuard from "./components/PlanGuard";

// Páginas lazy (reales)
const InicioClaseReal = lazy(() => import("./pages/InicioClase"));
const DesarrolloClase = lazy(() => import("./pages/DesarrolloClase"));
const CierreClase = lazy(() => import("./pages/CierreClase"));
const Pago = lazy(() => import("./pages/Pago"));
const ConfirmacionPago = lazy(() => import("./pages/ConfirmacionPago.jsx"));
const PlanificacionesReal = lazy(() => import("./pages/Planificaciones"));
const PlanificadorClase = lazy(() => import("./pages/PlanificadorClase"));
const PlanClaseEditor = lazy(() => import("./pages/PlanClaseEditor.jsx"));

/** Opcionales: si sueles alternar STUBS, los aliaso a las reales para que no rompa
 *  (si luego agregas los stubs, sólo cambia estas dos líneas)
 */
const InicioClaseStub = InicioClaseReal;
const PlanificacionesStub = PlanificacionesReal;

// ========== utilidades de diagnóstico (no rompen nada) ==========
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, err: null };
  }
  static getDerivedStateFromError(err) {
    return { hasError: true, err };
  }
  componentDidCatch(err, info) {
    console.error("[App ErrorBoundary] render error:", err, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            padding: 16,
            background: "#fff1f2",
            color: "#881337",
            fontFamily: "system-ui, sans-serif",
          }}
        >
          <h3>⚠️ Ocurrió un error renderizando la página</h3>
          <pre style={{ whiteSpace: "pre-wrap" }}>
            {String(this.state.err?.message || this.state.err || "Error desconocido")}
          </pre>
        </div>
      );
    }
    return this.props.children;
  }
}

function ScrollToTop() {
  const { pathname } = useLocation();
  React.useEffect(() => {
    try {
      window.scrollTo(0, 0);
    } catch {}
  }, [pathname]);
  return null;
}

function DevBanner() {
  const loc = useLocation();
  const [visible, setVisible] = React.useState(false);
  React.useEffect(() => {
    const qs = new URLSearchParams(window.location.search);
    const flag = qs.get("debug") === "1" || localStorage.getItem("debugApp") === "1";
    setVisible(!!flag);
  }, [loc]);
  if (!visible) return null;
  return (
    <div
      style={{
        position: "fixed",
        top: 8,
        right: 8,
        zIndex: 9999,
        background: "rgba(0,0,0,.75)",
        color: "#fff",
        padding: "6px 10px",
        borderRadius: 8,
        fontSize: 12,
        boxShadow: "0 4px 10px rgba(0,0,0,.2)",
      }}
    >
      ✅ App montada • ruta: <code>{loc.pathname}</code>
    </div>
  );
}
// ========== ☝️ utilidades de diagnóstico ==========

/* ─────────────────────────────────────────────────────────────
   🔧 Hook común con safety-timer para evitar pantallas en blanco
   ───────────────────────────────────────────────────────────── */
function useAuthReady() {
  const [ready, setReady] = React.useState(false);
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    let settled = false;
    const unsub = onAuthStateChanged(auth, (u) => {
      settled = true;
      setUser(u || null);
      setReady(true);
    });
    // ⛑️ si Firebase no emite a tiempo, liberamos la UI igualmente
    const t = setTimeout(() => {
      if (!settled) setReady(true);
    }, 1500);
    return () => {
      clearTimeout(t);
      unsub();
    };
  }, []);

  return { ready, user };
}

// 🔒 Exigir autenticación antes de mostrar la página
function RequireAuth({ children }) {
  const { ready, user } = useAuthReady();

  if (!ready) {
    return (
      <div style={{ padding: 16, fontFamily: "system-ui, sans-serif" }}>
        Cargando sesión…
      </div>
    );
  }
  // 👇 NO considerar autenticado si es anónimo
  const isAuthed = !!user && !user.isAnonymous;
  return isAuthed ? children : <Navigate to="/login" replace />;
}

// 🔒 Si el usuario ya está autenticado y visita /login, llevarlo a /inicio
function RedirectIfAuthed({ children }) {
  const { ready, user } = useAuthReady();

  // ⬇ Permite ver el login aunque ready=false usando ?nolock=1
  let forceShow = false;
  try {
    forceShow = new URLSearchParams(window.location.search).get("nolock") === "1";
  } catch {}

  if (!ready && !forceShow) return null;
  // 👇 solo redirigir si NO es anónimo
  const isAuthed = !!user && !user.isAnonymous;
  return isAuthed ? <Navigate to="/inicio" replace /> : children;
}

/* ⬇⬇⬇ Layout protegido con PlanGuard + Outlet (recomendado) */
function GuardedLayout() {
  return (
    <RequireAuth>
      <PlanGuard allowDuringTrial={true}>
        <Outlet />
      </PlanGuard>
    </RequireAuth>
  );
}
/* ⬆⬆⬆ */

/* ⬇⬇⬇ Wrapper para Desarrollo que navega a /cierre al terminar el cronómetro */
function DesarrolloRouteWrapper() {
  const navigate = useNavigate();
  return <DesarrolloClase duracion={30} onIrACierre={() => navigate("/cierre")} />;
}
/* ⬆⬆⬆ */

export default function App() {
  // 🔇 Log sólo en DEV o si hay flag de debug
  const __DEV__ =
    (typeof import.meta !== "undefined" && import.meta.env?.DEV) ||
    process.env.NODE_ENV !== "production" ||
    window.location.search.includes("debug=1") ||
    localStorage.getItem("debugApp") === "1";

  if (__DEV__) {
    console.log("App.jsx está renderizando");
  }

  // 🧪 salud de montaje rápida
  if (window.location.search.includes("ping")) {
    return (
      <div style={{ padding: 40, fontSize: 28, color: "lime", background: "#111" }}>
        ✅ App.jsx se montó correctamente
      </div>
    );
  }

  // 🔀 Elegir STUBS o REALES sin borrar nada
  const qs = new URLSearchParams(window.location.search);
  const USE_STUBS = qs.get("stub") === "1" || localStorage.getItem("stubApp") === "1";

  // ⚠️ Para NO ELIMINAR tus rutas duplicadas, pero evitar conflictos de enrutamiento
  const DISABLE_DUPLICATE_ROUTES = true;

  // ⬇⬇⬇ usar layout protegido con Outlet
  const USE_GUARDED_LAYOUT = true;

  // 🔁 Pick de componentes según flag
  const InicioClase = USE_STUBS ? InicioClaseStub : InicioClaseReal;
  const Planificaciones = USE_STUBS ? PlanificacionesStub : PlanificacionesReal;
// ...
    
}export default function App() {
  return (
    <Router>
      <ErrorBoundary>
        <Suspense
          fallback={
            <div style={{ padding: 16, fontFamily: "system-ui, sans-serif" }}>
              Cargando app…
            </div>
          }
        >
          <ScrollToTop />
          <DevBanner />

          <Routes>
            {/* Raíz → Inicio (para que siempre parta en Inicio tras login) */}
            <Route path="/" element={<Navigate to="/inicio" replace />} />

            {/* (Opcional) Si quieres seguir accediendo al Home, lo dejo en /home */}
            <Route path="/home" element={<Home />} />

            {/* Pública: para probar el editor */}
            <Route path="/plan-clase" element={<PlanClaseEditor />} />

            <Route
              path="/planificador/:grado/:unidadId"
              element={
                <PlanificadorClase
                  nivel="Básico"
                  asignatura="Matemática"
                  anio={2025}
                />
              }
            />

            {/* Registro / Participa públicas */}
            <Route path="/registro" element={<Registro />} />
            <Route path="/participa" element={<Participa />} />

            {/* 🔒 Login: si ya hay sesión, redirige a /inicio */}
            <Route
              path="/login"
              element={
                <RedirectIfAuthed>
                  <Login />
                </RedirectIfAuthed>
              }
            />

            {/* Perfil: privado */}
            <Route
              path="/perfil"
              element={
                <RequireAuth>
                  <Perfil />
                </RequireAuth>
              }
            />

            {/* ───────────────────────────────────────────────
                ✅ BLOQUE protegido bajo GuardedLayout (Outlet)
                ─────────────────────────────────────────────── */}
            {USE_GUARDED_LAYOUT && (
              <Route element={<GuardedLayout />}>
                <Route path="/horario" element={<HorarioEditable />} />
                <Route path="/planificaciones" element={<Planificaciones />} />
                <Route path="/inicio" element={<InicioClase />} />
                <Route path="/desarrollo" element={<DesarrolloRouteWrapper />} />
                <Route path="/cierre" element={<CierreClase duracion={10} />} />
              </Route>
            )}

            {/* 💾 Rutas protegidas originales (se conservan),
                pero las muestro SOLO si no usamos el layout con Outlet */}
            {!USE_GUARDED_LAYOUT && (
              <>
                <Route
                  path="/horario"
                  element={
                    <RequireAuth>
                      <PlanGuard>
                        <HorarioEditable />
                      </PlanGuard>
                    </RequireAuth>
                  }
                />
                <Route
                  path="/planificaciones"
                  element={
                    <RequireAuth>
                      <PlanGuard>
                        <Planificaciones />
                      </PlanGuard>
                    </RequireAuth>
                  }
                />
                <Route
                  path="/inicio"
                  element={
                    <RequireAuth>
                      <PlanGuard>
                        <InicioClase />
                      </PlanGuard>
                    </RequireAuth>
                  }
                />
                <Route
                  path="/desarrollo"
                  element={
                    <RequireAuth>
                      <DesarrolloClase duracion={30} onIrACierre={() => {}} />
                    </RequireAuth>
                  }
                />
                <Route
                  path="/cierre"
                  element={
                    <RequireAuth>
                      <CierreClase duracion={10} />
                    </RequireAuth>
                  }
                />
              </>
            )}

            {/* Duplicados originales: los CONSERVO pero no los monto para evitar bypass del PlanGuard */}
            {!DISABLE_DUPLICATE_ROUTES && <Route path="/inicio" element={<InicioClase />} />}
            {!DISABLE_DUPLICATE_ROUTES && (
              <Route path="/planificaciones" element={<Planificaciones />} />
            )}
            {!DISABLE_DUPLICATE_ROUTES && (
              <Route path="/horario" element={<HorarioEditable />} />
            )}

            {/* Pago (lo dejas protegido como estaba) */}
            <Route
              path="/pago"
              element={
                <RequireAuth>
                  <Pago />
                </RequireAuth>
              }
            />

            {/* ✅ Confirmación de pago (pública si así la tenías) */}
            <Route path="/confirmacion-pago" element={<ConfirmacionPago />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/inicio" replace />} />
          </Routes>
        </Suspense>
      </ErrorBoundary>
    </Router>
  );
}

















