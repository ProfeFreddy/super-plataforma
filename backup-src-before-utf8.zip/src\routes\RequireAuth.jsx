// src/routes/RequireAuth.jsx
import React, { useEffect, useState } from "react";
import { Outlet, Navigate, useLocation } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "../firebase";

export default function RequireAuth() {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u || null);
      setReady(true);
    });
    return () => unsub();
  }, []);

  if (!ready) {
    return <div style={{ padding: 24 }}>Cargando…</div>;
  }

  // si no hay sesión, envia a login, recordando a dónde iba
  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // hay sesión → deja pasar a la ruta privada
  return <Outlet />;
}
