// InicioClase.jsx 
import React, { useEffect, useMemo, useRef, useState, useContext } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import QRCode from "react-qr-code";
import WordCloud from "react-d3-cloud";
import { db } from "../firebase";
import { getClaseVigente, getYearWeek, slotIdFrom } from "../services/PlanificadorService";
import { PlanContext } from "../context/PlanContext";
import { PLAN_CAPS } from "../lib/planCaps";
import { syncSlotsFromHorario } from "../services/slots";
import FichaClaseSticky from "../components/FichaClaseSticky";

import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  orderBy,
  setDoc,
  serverTimestamp,
} from "firebase/firestore";
import { auth } from "../firebase";
import { onAuthStateChanged, signInAnonymously } from "firebase/auth";
/* ⚠️ Duplicado conservado: para evitar 'Identifier ... has already been declared',
   lo importo con un alias de espacio de nombres. */
import * as FichaClaseSticky__DUP from "../components/FichaClaseSticky";

// Ô£à NUEVO: helper de nivel y servicio OA
import { nivelDesdeCurso } from "../lib/niveles";
import { getPrimerOA } from "../services/curriculoService";

// Ô¼çÔ¼ç PON ESTO CERCA DE TUS UTILIDADES DE CONTADOR Ô¼çÔ¼ç

function makeCountKey(slotId = "0-0") {
  const uid = auth.currentUser?.uid || localStorage.getItem("uid") || "anon";
  const yw = getYearWeek(); // p.ej. "2025-39"
  return `ic_countdown_end:${uid}:${yw}:${slotId}`;
}

// === DEBUG DE TIEMPO (solo PRUEBA) ===============================
const FORCE_TEST_TIME = false; // ÔåÉ usa hora real
const TEST_DATETIME_ISO = "2025-08-11T08:10:00"; // Lunes 11-08-2025 08:10
function getNowForSchedule() {
  return FORCE_TEST_TIME ? new Date(TEST_DATETIME_ISO) : new Date();
}

/* Ô£à Fallback seguro para el contexto (sin hooks) */
const PLAN_DEFAULTS = {
  user: null,
  plan: "FREE",
  caps: PLAN_CAPS.FREE,
  loading: false,
};

// ====== estilos (alineados con Home: #2193b0 ÔåÆ #6dd5ed) ======
const COLORS = {
  brandA: "#2193b0",
  brandB: "#6dd5ed",
  white: "#ffffff",
  textDark: "#1f2937",
  textMuted: "#475569",
  border: "#e5e7eb",
  btnText: "#2193b0",
};
const page = {
  minHeight: "100vh",
  background: `linear-gradient(to right, ${COLORS.brandA}, ${COLORS.brandB})`,
  padding: "2rem",
  fontFamily: "Segoe UI, sans-serif",
  color: COLORS.white,
  boxSizing: "border-box",
};
const row = (gap = "1rem") => ({
  display: "grid",
  gridTemplateColumns: "1fr 2fr 1fr",
  gap,
  alignItems: "stretch",
});
const card = {
  background: COLORS.white,
  color: COLORS.textDark,
  borderRadius: 12,
  padding: "1rem",
  boxShadow: "0 6px 18px rgba(16,24,40,.06), 0 2px 6px rgba(16,24,40,.03)",
  border: `1px solid ${COLORS.border}`,
  maxWidth: "100%",
  overflow: "hidden",
};
const input = {
  width: "100%",
  padding: "0.75rem 1rem",
  borderRadius: 10,
  border: `1px solid ${COLORS.border}`,
  outline: "none",
  fontSize: "1rem",
  boxSizing: "border-box",
};
const btnWhite = {
  background: COLORS.white,
  color: COLORS.btnText,
  border: "none",
  borderRadius: 10,
  padding: ".6rem .9rem",
  fontWeight: 700,
  cursor: "pointer",
  boxShadow: "0 4px 10px rgba(0,0,0,.15)",
};
const btnTiny = {
  ...btnWhite,
  padding: ".35rem .6rem",
  fontWeight: 600,
  boxShadow: "none",
  border: `1px solid ${COLORS.border}`,
};

// ====== cron├│metro ======
const COUNT_KEY = "inicioClase_countdown_end";
const getRemaining = (endMs) => {
  const diff = Math.max(0, endMs - Date.now());
  const m = Math.floor(diff / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  return { m, s, finished: diff === 0 };
};
const formatMMSS = (m, s) => `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;

// ------------------------------------------------------------
// MODO PRUEBA: forzar hora/d├¡a v├¡a query (?at=HH:MM&dow=1..5)
// ------------------------------------------------------------
function nowFromQuery() {
  const q = new URLSearchParams(window.location.search);
  const at = q.get("at");
  if (!at) return new Date();
  const [hh, mm] = at.split(":").map(Number);
  const d = new Date();
  d.setHours(hh);
  d.setMinutes(mm);
  d.setSeconds(0);
  d.setMilliseconds(0);
  return d;
}
function dowFromQuery() {
  const q = new URLSearchParams(window.location.search);
  const v = Number(q.get("dow"));
  return v >= 1 && v <= 5 ? v : null;
}

/* Ô×ò NUEVO: permitir forzar slot v├¡a query (?slot=fila-col) */
function slotFromQuery() {
  try {
    const q = new URLSearchParams(window.location.search || "");
    const s = q.get("slot");
    if (!s) return null;
    const [f, c] = s.split("-").map((n) => Number(n));
    if (Number.isInteger(f) && Number.isInteger(c)) return `${f}-${c}`;
  } catch (e) {}
  return null;
}

// Ô¼ç´©Å Reconstruye la matriz de horario desde rutas nuevas/legacy, con fallback
async function readHorarioMatrix(uid) {
  try {
    const hRef = doc(db, "horarios", uid);
    const hSnap = await getDoc(hRef);
    if (hSnap.exists() && Array.isArray(hSnap.data()?.horario)) {
      return hSnap.data().horario;
    }
  } catch (e) {
    console.debug("[horarios] fallback -> usuarios", e?.code);
  }
  try {
    const uRef = doc(db, "usuarios", uid);
    const uSnap = await getDoc(uRef);
    if (!uSnap.exists()) return null;
    const u = uSnap.data();
    if (u.horarioMatriz) {
      const keys = Object.keys(u.horarioMatriz).sort(
        (a, b) => Number(a.replace("f", "")) - Number(b.replace("f", ""))
      );
      return keys.map((k) => u.horarioMatriz[k]);
    }
    if (Array.isArray(u.horarioSlots)) {
      const rows = u.horarioConfig?.bloquesGenerados?.length ?? 16;
      const cols = 5;
      const matrix = Array.from({ length: rows }, () =>
        Array.from({ length: cols }, () => ({
          asignatura: "",
          nivel: "",
          seccion: "",
          unidad: "",
          objetivo: "",
          habilidades: "",
        }))
      );
      u.horarioSlots.forEach((s) => {
        if (s?.fila != null && s?.col != null) {
          matrix[s.fila][s.col] = {
            asignatura: s.asignatura ?? "",
            nivel: s.nivel ?? "",
            seccion: s.seccion ?? "",
            unidad: s.unidad ?? "",
            objetivo: s.objetivo ?? "",
            habilidades: Array.isArray(s.habilidades)
              ? s.habilidades.join(", ")
              : (s.habilidades ?? ""),
          };
        }
      });
      return matrix;
    }
  } catch (e) {
    console.debug("[usuarios] read error:", e?.code);
  }
  return null;
}

// Ô¼à´©Å helpers para calcular el slot actual usando horarioConfig.marcas
const colDeHoy = () => {
  const qDow = dowFromQuery();
  const d =
    qDow != null
      ? qDow
      : (FORCE_TEST_TIME ? getNowForSchedule().getDay() : new Date().getDay());
  return d >= 1 && d <= 5 ? d - 1 : 0; // 0..4 = L..V
};
const filaDesdeMarcas = (marcas = []) => {
  const now = FORCE_TEST_TIME ? getNowForSchedule() : nowFromQuery();
  const mins = now.getHours() * 60 + now.getMinutes();
  for (let i = 0; i < marcas.length - 1; i++) {
    const start = marcas[i][0] * 60 + marcas[i][1];
    const end = marcas[i + 1][0] * 60 + marcas[i + 1][1];
    if (mins >= start && mins < end) return i;
  }
  return 0;
};

/* ­ƒöº NUEVO HELPER: acepta varios formatos de horarioConfig */
function getMarcasFromConfig(cfg = {}) {
  // a) array de [h,m]
  if (Array.isArray(cfg.marcas) && Array.isArray(cfg.marcas[0])) return cfg.marcas;

  // b) array de maps {h,m}
  if (Array.isArray(cfg.marcas) && cfg.marcas.length && typeof cfg.marcas[0] === "object") {
    return cfg.marcas.map((x) => [Number(x.h) || 0, Number(x.m) || 0]);
  }

  // c) marcasStr: ["08:00", ...]
  if (Array.isArray(cfg.marcasStr)) {
    return cfg.marcasStr.map((s) => {
      const [h, m] = String(s).split(":").map((n) => Number(n) || 0);
      return [h, m];
    });
  }

  // d) bloquesGenerados: ["08:00 - 08:45", ...]
  if (Array.isArray(cfg.bloquesGenerados) && cfg.bloquesGenerados.length) {
    const startTimes = cfg.bloquesGenerados.map((b) => String(b).split(" - ")[0]);
    const lastEnd = String(cfg.bloquesGenerados.at(-1)).split(" - ")[1];
    return [...startTimes, lastEnd].map((s) => {
      const [h, m] = s.split(":").map((n) => Number(n) || 0);
      return [h, m];
    });
  }

  return [];
}

// ========= NUEVO: sala/c├│digo para la nube de palabras =========
const randCode = () => String(Math.floor(10000 + Math.random() * 90000)); // 5 d├¡gitos

// ========= NUEVO: helpers de fiabilidad del cloud =========
function supportsSvgTextBBox() {
  try {
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("width", "0");
    svg.setAttribute("height", "0");
    const t = document.createElementNS(NS, "text");
    t.textContent = "m";
    svg.appendChild(t);
    document.body.appendChild(svg);
    const bbox = t.getBBox();
    document.body.removeChild(svg);
    return Number.isFinite(bbox?.width) && bbox.width > 0;
  } catch (e) {
    return false;
  }
}
const isProblematicUA = () => /OPR|Opera Mini|Opera/i.test(navigator.userAgent);

// Error boundary para capturar fallos del WordCloud y caer a HTML
class CloudBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    try {
      localStorage.setItem("cloudMode", "html");
    } catch (e) {}
    return { hasError: true };
  }
  componentDidCatch(err) {
    console.error("[WordCloud SVG] error:", err);
  }
  render() {
    return this.state.hasError ? this.props.fallback : this.props.children;
  }
}

// ­ƒö░ NUEVO: ErrorBoundary global para evitar pantallas en blanco
class GlobalBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, err: null };
  }
  static getDerivedStateFromError(err) {
    return { hasError: true, err };
  }
  componentDidCatch(err, info) {
    console.error("[InicioClase] render error:", err, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: "100vh",
            display: "grid",
            placeItems: "center",
            background: "#f8fafc",
            fontFamily: "Segoe UI, sans-serif",
          }}
        >
          <div
            style={{
              maxWidth: 720,
              background: "#fff",
              border: "1px solid #e5e7eb",
              borderRadius: 12,
              boxShadow: "0 10px 30px rgba(0,0,0,.05)",
              padding: "20px",
            }}
          >
            <h3 style={{ margin: "0 0 8px" }}>
              Se produjo un error al dibujar la pantalla
            </h3>
            <div style={{ color: "#475569", marginBottom: 12 }}>
              Prueba con los modos de diagn├│stico:
            </div>
            <code
              style={{
                display: "block",
                background: "#0f172a",
                color: "#e2e8f0",
                padding: "10px",
                borderRadius: 8,
                overflowX: "auto",
              }}
            >
              {window.location.origin}/inicio?safe=1&bypass=1{"\n"}
              {window.location.origin}/inicio?nocloud=1&bypass=1
            </code>
            <div style={{ marginTop: 12, color: "#475569" }}>
              Detalle:{" "}
              {String(this.state.err?.message || this.state.err) ||
                "(sin mensaje)"}
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// Componente fallback HTML (palabras coloridas, crecimiento por frecuencia)
function HtmlCloud({ data, palette, fontSize }) {
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: 12,
        alignItems: "center",
        padding: "6px 2px",
      }}
    >
      {data.map((w, i) => (
        <span
          key={w.key || `${w.text}_${i}`}
          style={{
            fontWeight: 800,
            fontSize: fontSize(w),
            lineHeight: 1.05,
            color: palette[i % palette.length],
            whiteSpace: "nowrap",
            userSelect: "none",
          }}
          title={`${w.text} ├ù${w.value}`}
        >
          {w.text}
        </span>
      ))}
    </div>
  );
}

/* ========= NUEVO: CanvasCloud =========
   Dibuja una nube centrada con disposici├│n en espiral (tipo Mentimeter).
   Se usa cuando 'cloudMode' cae a "html" para evitar el fallback en fila. */
function CanvasCloud({ data, palette, width, height, fontSize }) {
  const ref = useRef(null);

  // Ô£à FIX: define un 'authed' local para que no marque no-undef
  const authed = !!(auth.currentUser?.uid || localStorage.getItem("uid"));

  useEffect(() => {
    if (!authed) return;
    const uid = auth.currentUser?.uid || localStorage.getItem("uid");
    if (!uid) return;

    // evita repetir la sincronizaci├│n cada render
    if (window.__slotsSyncedForUid === uid) return;

    (async () => {
      try {
        await syncSlotsFromHorario(uid, { overwrite: false }); // crea lo que falte, no pisa lo ya escrito
        window.__slotsSyncedForUid = uid;
        console.log("Ô£ô slots sincronizados desde el horario");
      } catch (e) {
        console.warn("syncSlotsFromHorario error:", e);
      }
    })();
  }, [authed]);

  useEffect(() => {
    const cvs = ref.current;
    if (!cvs) return;
    const dpr = window.devicePixelRatio || 1;
    cvs.width = Math.floor(width * dpr);
    cvs.height = Math.floor(height * dpr);
    cvs.style.width = `${width}px`;
    cvs.style.height = `${height}px`;

    const ctx = cvs.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);

    // ordenar de mayor a menor para colocar primero las m├ís grandes
    const words = [...data].sort((a, b) => fontSize(b) - fontSize(a));

    const centerX = width / 2;
    const centerY = height / 2;
    const placed = [];
    const padding = 4;

    // espiral aritm├®tica
    const a = 0;
    const b = 6;
    const step = 0.35;

    const collides = (r1, r2) =>
      !(
        r2.x > r1.x + r1.w ||
        r2.x + r2.w < r1.x ||
        r2.y > r1.y + r1.h ||
        r2.y + r2.h < r1.y
      );

    words.forEach((w, idx) => {
      const size = Math.max(12, Math.floor(fontSize(w)));
      const text = String(w.text || "");
      const color = palette[idx % palette.length];

      let t = 0;
      let found = false;
      let px = centerX,
        py = centerY,
        rect;

      // buscar posici├│n libre sobre la espiral
      for (let tries = 0; tries < 2000; tries++) {
        const r = a + b * t;
        px = centerX + r * Math.cos(t);
        py = centerY + r * Math.sin(t);

        const metricsCtx = ctx;
        metricsCtx.font = `bold ${size}px Segoe UI, sans-serif`;
        metricsCtx.textBaseline = "middle";
        metricsCtx.textAlign = "center";

        const metrics = metricsCtx.measureText(text);
        const tw = metrics.width;
        const th = size * 0.9; // aprox alto
        rect = {
          x: px - tw / 2 - padding,
          y: py - th / 2 - padding,
          w: tw + 2 * padding,
          h: th + 2 * padding,
        };

        if (placed.every((p) => !collides(p, rect))) {
          found = true;
          break;
        }
        t += step;
      }

      ctx.fillStyle = color;
      ctx.globalAlpha = 0.95;
      ctx.fillText(text, px, py);
      ctx.globalAlpha = 1;

      if (found) placed.push(rect);
    });
  }, [data, palette, width, height, fontSize]);

  return <canvas ref={ref} style={{ display: "block", width, height }} />;
}

/* ­ƒöÄ NUEVO: overlay de debug para confirmar montaje de InicioClase */
function ICDebugBadge({ show, data }) {
  if (!show) return null;
  const row = (k, v) => (
    <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
      <span style={{ opacity: 0.75 }}>{k}</span>
      <b>{String(v)}</b>
    </div>
  );
  return (
    <div
      style={{
        position: "fixed",
        left: 12,
        bottom: 12,
        zIndex: 9999,
        background: "#052e16",
        color: "#d1fae5",
        padding: "10px 12px",
        borderRadius: 10,
        boxShadow: "0 8px 24px rgba(0,0,0,.35)",
        width: 260,
        fontFamily: "Segoe UI, system-ui, sans-serif",
        fontSize: 12,
      }}
    >
      <div style={{ fontWeight: 800, marginBottom: 6 }}>InicioClase ┬À debug</div>
      <div style={{ display: "grid", gap: 4 }}>
        {Object.entries(data).map(([k, v]) => row(k, v))}
      </div>
    </div>
  );
}

function InicioClase() {
  const navigate = useNavigate();
  const location = useLocation();

  // ­ƒöº NUEVO: flags por query para pruebas
  const __qs = new URLSearchParams(window.location.search || "");
  const SAFE_MODE = __qs.get("safe") === "1";
  const DISABLE_CLOUD = __qs.get("nocloud") === "1";
  const DEBUG_ON = __qs.get("debug") === "1";
  try {
    console.log("[InicioClase] flags", { SAFE_MODE, DISABLE_CLOUD });
  } catch (e) {}

  /* Ô£à Uso correcto del contexto DENTRO del componente, con fallback */
  const {
    user = PLAN_DEFAULTS.user,
    plan = PLAN_DEFAULTS.plan,
    caps = PLAN_DEFAULTS.caps,
    loading = PLAN_DEFAULTS.loading,
  } = useContext(PlanContext) || PLAN_DEFAULTS;
  const [currentSlotId, setCurrentSlotId] = useState("0-0");
  const [authed, setAuthed] = useState(false);
  const [nombre, setNombre] = useState("Profesor");
  const [asignaturaProfe, setAsignaturaProfe] = useState(""); // ÔåÉ fallback asignatura
  const [horaActual, setHoraActual] = useState("");
  const [claseActual, setClaseActual] = useState(null);
  const [planSug, setPlanSug] = useState(null);
  const [preguntaClase, setPreguntaClase] = useState(
    "┬┐Cu├íl palabra representa mejor la ├║ltima clase?"
  );
  const [ultimos, setUltimos] = useState([]);

  // ADICIONAL: clase vigente segun plan semanal
  const [claseVigente, setClaseVigente] = useState(null);

  // Sala / C├│digo y URL para estudiantes
  const [salaCode, setSalaCode] = useState(localStorage.getItem("salaCode") || "");
  const [participaURL, setParticipaURL] = useState("");

  // ÔÜá´©Å Para mantener tu bloque opcional m├ís abajo:
  const [palabras, setPalabras] = useState([]); // dummy para evitar referencias indefinidas

  // === NUEVO: modo de render del cloud ===
  const [cloudMode, setCloudMode] = useState("auto");

  // === Curr├¡culo (OA + Habilidades) para la clase vigente
  const [curriculo, setCurriculo] = useState(null);
  const [cargandoCurriculo, setCargandoCurriculo] = useState(true);

  // ­ƒöÆ NUEVO: desactivar login an├│nimo aqu├¡ (sin borrar tu c├│digo)
  const ALLOW_ANON = true;

  // Ô£à tomar slot forzado o recordado apenas monta
  useEffect(() => {
    const s = slotFromQuery() || localStorage.getItem("__lastSlotId");
    if (s) setCurrentSlotId(s);
  }, []);

  // === Auth al montar ===
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!u) {
        if (ALLOW_ANON) {
          try {
            await signInAnonymously(auth);
          } catch (e) {
            console.error("Anon sign-in:", e);
          }
        }
        return; // ✅ NO redirigimos al login desde aquí
      } else {
        setAuthed(true);
        const stored = localStorage.getItem("uid");
        if (stored !== u.uid) localStorage.setItem("uid", u.uid);
      }
    });
    return () => unsub();
  }, []);

  // ­ƒö╣ NUEVO: si vengo de postLogin(), priorizo lo que trae en state
  useEffect(() => {
    const st = location?.state || null;
    if (!st) return;

    try {
      const prof = st.profesor || {};
      if (prof?.nombre) setNombre(prof.nombre);

      const cls = st.clase || null;
      if (cls) {
        setClaseActual((prev) => ({
          ...(prev || {}),
          unidad: cls.unidad ?? prev?.unidad ?? "(sin unidad)",
          objetivo: cls.objetivo ?? prev?.objetivo ?? "(sin objetivo)",
          habilidades:
            cls.habilidades ?? prev?.habilidades ?? "(sin habilidades)",
          asignatura:
            cls.asignatura ?? prev?.asignatura ?? asignaturaProfe ?? "(sin asignatura)",
        }));
      }
    } catch (e) {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ADICIONAL: leer clase vigente y reflejar en UI (sin borrar tu flujo)
  useEffect(() => {
    (async () => {
      try {
        const res = await getClaseVigente(new Date());
        setClaseVigente(res);
        if (res && (res.unidad || res.objetivo || res.habilidades)) {
          setClaseActual((prev) => ({
            ...(prev || {}),
            unidad: res.unidad ?? prev?.unidad ?? "(sin unidad)",
            objetivo: res.objetivo ?? prev?.objetivo ?? "(sin objetivo)",
            habilidades:
              res.habilidades ?? prev?.habilidades ?? "(sin habilidades)",
            asignatura:
              res.asignatura ??
              prev?.asignatura ??
              asignaturaProfe ??
              "(sin asignatura)",
          }));
        }
      } catch (e) {
        console.error("[Inicio] getClaseVigente:", e);
      }
    })();
  }, [asignaturaProfe]);

  // ­ƒåò Cargar curr├¡culo (OA + Habilidades) cuando cambie la clase vigente
  useEffect(() => {
    let stop = false;
    async function run() {
      try {
        setCargandoCurriculo(true);
        setCurriculo(null);

        const cod = claseVigente?.codUnidad || null;
        if (!cod) {
          setCargandoCurriculo(false);
          return;
        }
        const ref = doc(db, "curriculo", cod);
        const snap = await getDoc(ref);
        if (!stop) {
          if (snap.exists()) setCurriculo(snap.data());
          setCargandoCurriculo(false);
        }
      } catch (e) {
        console.warn("[curriculo] read:", e?.code || e?.message);
        if (!stop) setCargandoCurriculo(false);
      }
    }
    run();
    return () => {
      stop = true;
    };
  }, [claseVigente]);

  // reloj
  useEffect(() => {
    setHoraActual(new Date().toLocaleTimeString());
    const id = setInterval(() => setHoraActual(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(id);
  }, []);

  // =========================
  // Ô£à CRON├ôMETRO CORREGIDO
  // =========================
  const [remaining, setRemaining] = useState({ m: 10, s: 0 });

  // Ô£à Nuevo efecto: controla el countdown por SLOT, sin hooks anidados
  useEffect(() => {
    if (!currentSlotId) return;

    const key = makeCountKey(currentSlotId);
    // intenta leer el fin desde el key por-slot o desde el key legacy
    let endStr = localStorage.getItem(key) || localStorage.getItem(COUNT_KEY);

    if (!endStr) {
      const endTime = Date.now() + 10 * 60 * 1000; // 10 min
      localStorage.setItem(key, String(endTime));
      localStorage.setItem(COUNT_KEY, String(endTime)); // compatibilidad atr├ís
      endStr = String(endTime);
    }

    const endMs = Number(endStr);
    const tick = () => setRemaining(getRemaining(endMs));

    tick(); // primer c├ílculo inmediato
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [currentSlotId]);

  // ­ƒöü Reinicio manual a 10:00 (escribe en ambas llaves para compatibilidad)
  const resetCountdown = () => {
    const endTime = Date.now() + 10 * 60 * 1000;
    const key = makeCountKey(currentSlotId || "0-0");
    localStorage.setItem(key, String(endTime));
    localStorage.setItem(COUNT_KEY, String(endTime));
    setRemaining(getRemaining(endTime));
  };

  // ­ƒöº NUEVO: helper para construir la ficha a enviar a Desarrollo
  const makeFicha = () => {
    const habilidadesTxt =
      Array.isArray(claseActual?.habilidades)
        ? claseActual.habilidades.join("; ")
        : (claseActual?.habilidades ?? "");
    return {
      // m├¡nimos ├║tiles para FichaClaseSticky
      asignatura: claseActual?.asignatura ?? asignaturaProfe ?? "(sin asignatura)",
      unidad: claseActual?.unidad ?? "(sin unidad)",
      objetivo: claseActual?.objetivo ?? "(sin objetivo)",
      habilidades: habilidadesTxt ?? "(sin habilidades)",
      // contexto extra que ayuda en Desarrollo
      nivel: claseActual?.nivel ?? "",
      seccion: claseActual?.seccion ?? "",
      bloque: claseActual?.bloque ?? "",
      dia: claseActual?.dia ?? "",
      codUnidad: claseVigente?.codUnidad ?? planSug?.codUnidad ?? "",
      programaUrl: planSug?.programaUrl ?? "",
      fuentes: Array.isArray(planSug?.fuentes) ? planSug.fuentes : [],
      // por si tu proxy/plan lo usa
      planId: planSug?.planId ?? "",
      updatedAt: Date.now(),
    };
  };

  // ­ƒæë Cuando termina el countdown, navega a /desarrollo con el estado (+ ficha)
  useEffect(() => {
    if (remaining.m === 0 && remaining.s === 0) {
      const key = makeCountKey(currentSlotId || "0-0");
      const endStr =
        localStorage.getItem(key) || localStorage.getItem(COUNT_KEY) || String(Date.now());
      const endMs = Number(endStr);
      try { localStorage.setItem("__lastSlotId", currentSlotId || "0-0"); } catch (e) {}
      const ficha = makeFicha(); // Ô¼à´©Å NUEVO
      navigate("/desarrollo", {
        state: {
          slotId: currentSlotId || "0-0",
          endMs,
          clase: claseActual || null,
          ficha, // Ô¼à´©Å NUEVO
        },
      });
    }
  }, [remaining, navigate, currentSlotId, claseActual]);

  // ========= NUEVO: crear/asegurar sala + armar URL QR =========
  useEffect(() => {
    (async () => {
      let code = salaCode;
      if (!code) {
        code = randCode();
        localStorage.setItem("salaCode", code);
        setSalaCode(code);
      }
      try {
        await setDoc(
          doc(db, "salas", code),
          { activa: true, createdAt: serverTimestamp() },
          { merge: true }
        );
      } catch (e) {
        console.warn("[sala] setDoc:", e?.code || e?.message);
      }

      // host override para QR
      const hostOverride = localStorage.getItem("hostOverride"); // ej: http://192.168.0.22:3005
      const base =
        hostOverride && /^https?:\/\/.*/.test(hostOverride)
          ? hostOverride
          : window.location.origin;
      setParticipaURL(`${base}/participa?code=${code}`);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ========= NUEVO (authed): volver a asegurar sala cuando ya hay sesi├│n =========
  useEffect(() => {
    if (!authed) return;
    if (window.__salaInitDone) return;
    (async () => {
      try {
        let code = salaCode || localStorage.getItem("salaCode");
        if (!code) {
          code = randCode();
          localStorage.setItem("salaCode", code);
          setSalaCode(code);
        }

        await setDoc(
          doc(db, "salas", code),
          { activa: true, createdAt: serverTimestamp() },
          { merge: true }
        );

        const hostOverride = localStorage.getItem("hostOverride"); // ej: http://TU_IP_LAN:3000
        const base =
          hostOverride && /^https?:\/\/.*/.test(hostOverride)
            ? hostOverride
            : window.location.origin;
        setParticipaURL(`${base}/participa?code=${code}`);

        window.__salaInitDone = true;
      } catch (e) {
        console.warn("[sala][authed] setDoc:", e?.code || e?.message);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authed, salaCode]);

  // nombre profe + pregunta (solo si autenticado)
  useEffect(() => {
    if (!authed) return;
    (async () => {
      const uid = auth.currentUser?.uid || localStorage.getItem("uid");
      if (uid) {
        try {
          const uref = doc(db, "usuarios", uid);
          const usnap = await getDoc(uref);
          if (usnap.exists()) {
            const u = usnap.data();
            if (u?.nombre) setNombre(u.nombre);
            if (u?.asignatura) setAsignaturaProfe(u.asignatura); // ÔåÉ fallback
          }
        } catch (e) {
          console.warn("[usuarios] read nombre:", e?.code);
        }
      }
      try {
        const pref = doc(db, "preguntaClase", "actual");
        const psnap = await getDoc(pref);
        if (psnap.exists() && psnap.data()?.texto)
          setPreguntaClase(psnap.data().texto);
      } catch (e) {
        console.warn("[preguntaClase] read:", e?.code);
      }
    })();
  }, [authed]);

  // Ô¼çÔ¼çÔ¼çÔ¼çÔ¼çÔ¼çÔ¼çÔ¼çÔ¼çÔ¼ç  NUEVO BLOQUE: Fallback uniforme desde `profesores/{uid}` y `usuarios/{uid}`
  // Igualamos el comportamiento de DesarrolloClase para que nunca quede "(sin unidad)"
  useEffect(() => {
    if (!authed) return;

    const pick = (...vals) => {
      for (const v of vals) {
        const s = (v ?? "").toString().trim();
        if (s && !/^\(sin/i.test(s)) return s;
      }
      return vals.find(Boolean) || "";
    };
    const normHabs = (x) => (Array.isArray(x) ? x.join(", ") : (x ?? ""));

    (async () => {
      try {
        const uid = auth.currentUser?.uid || localStorage.getItem("uid");
        if (!uid) return;

        // 1) profesores/{uid}
        try {
          const pref = doc(db, "profesores", uid);
          const psnap = await getDoc(pref);
          if (psnap.exists()) {
            const p = psnap.data() || {};
            setClaseActual((prev) => ({
              ...(prev || {}),
              unidad: pick(prev?.unidad, p.unidad, p.unidadInicial, "(sin unidad)"),
              objetivo: pick(prev?.objetivo, p.objetivo, p.objetivoInicial, "(sin objetivo)"),
              habilidades: pick(
                prev?.habilidades,
                normHabs(p.habilidades),
                "(sin habilidades)"
              ),
              asignatura: pick(prev?.asignatura, asignaturaProfe, p.asignatura, "(sin asignatura)"),
              curso: pick(prev?.curso, p.curso, "(sin curso)"),
            }));
          }
        } catch (e) {
          console.warn("[Inicio] profesores read:", e?.code || e);
        }

        // 2) usuarios/{uid} como ├║ltimo respaldo (unidadInicial/unidad)
        try {
          const uref = doc(db, "usuarios", uid);
          const usnap = await getDoc(uref);
          if (usnap.exists()) {
            const u = usnap.data() || {};
            setClaseActual((prev) => ({
              ...(prev || {}),
              unidad: (prev?.unidad && !/^\(sin/i.test(prev?.unidad)) ? prev?.unidad : (u.unidadInicial ?? u.unidad ?? "(sin unidad)"),
              objetivo: (prev?.objetivo && !/^\(sin/i.test(prev?.objetivo)) ? prev?.objetivo : (u.objetivo ?? "(sin objetivo)"),
              habilidades: (prev?.habilidades && !/^\(sin/i.test(prev?.habilidades)) ? prev?.habilidades : (normHabs(u.habilidades) || "(sin habilidades)"),
              asignatura: pick(prev?.asignatura, asignaturaProfe, u.asignatura, "(sin asignatura)"),
              curso: pick(prev?.curso, u.curso, "(sin curso)"),
            }));
          }
        } catch (e) {
          console.warn("[Inicio] usuarios fallback:", e?.code || e);
        }
      } catch (e) {}
    })();
  }, [authed, asignaturaProfe]);
  // Ô¼åÔ¼åÔ¼åÔ¼åÔ¼åÔ¼åÔ¼åÔ¼åÔ¼åÔ¼å  FIN NUEVO BLOQUE

  // si hay horarioConfig.marcas -> clases_detalle/{uid}/slots/{fila}-{col}
  useEffect(() => {
    if (!authed) return;
    (async () => {
      try {
        const uid = auth.currentUser?.uid || localStorage.getItem("uid");
        if (!uid) return;

        // Ô£à prioridad: slot por query (?slot=f-c)
        const sQ = slotFromQuery();
        if (sQ) {
          setCurrentSlotId(sQ);
          try { localStorage.setItem("__lastSlotId", sQ); } catch (e) {}
          const drefQ = doc(db, "clases_detalle", uid, "slots", sQ);
          const dsQ = await getDoc(drefQ);
          if (dsQ.exists()) {
            const det = dsQ.data();
            setClaseActual((prev) => ({
              ...(prev || {}),
              unidad: det.unidad ?? prev?.unidad ?? "(sin unidad)",
              objetivo: det.objetivo ?? prev?.objetivo ?? "(sin objetivo)",
              habilidades: det.habilidades ?? prev?.habilidades ?? "(sin habilidades)",
              asignatura: det.asignatura ?? prev?.asignatura ?? asignaturaProfe ?? "(sin asignatura)",
            }));
          } else {
            // ­ƒöü Fallback: leer celda del horario si existe y sembrar detalle
            try {
              const hcell = await getDoc(doc(db, "horarios", uid, "celdas", sQ));
              if (hcell.exists()) {
                const hx = hcell.data() || {};
                const payload = {
                  asignatura: hx.asignatura ?? "",
                  nivel: hx.nivel ?? "",
                  seccion: hx.seccion ?? "",
                  unidad: hx.unidad ?? "",
                  objetivo: hx.objetivo ?? "",
                  habilidades: Array.isArray(hx.habilidades) ? hx.habilidades.join(", ") : (hx.habilidades ?? ""),
                  updatedAt: serverTimestamp(),
                };
                if (payload.unidad || payload.objetivo || payload.habilidades) {
                  await setDoc(drefQ, payload, { merge: true });
                  setClaseActual((prev) => ({ ...(prev || {}), ...payload }));
                }
              }
            } catch (e) {}
          }
          return; // no sigas con marcas si ya forzamos slot
        }

        const uref = doc(db, "usuarios", uid);
        const usnap = await getDoc(uref);
        const cfg = usnap.exists() ? usnap.data().horarioConfig || {} : {};
        const marcasArr = getMarcasFromConfig(cfg);               // Ô¼à´©Å USO DEL HELPER
        if (marcasArr.length > 1) {
          const fila = filaDesdeMarcas(marcasArr);                // Ô¼à´©Å ahora con marcas normalizadas
          const col = colDeHoy();
          const slotId = `${fila}-${col}`;
          setCurrentSlotId(slotId);
          try { localStorage.setItem("__lastSlotId", slotId); } catch (e) {}
          const dref = doc(db, "clases_detalle", uid, "slots", slotId);
          const dsnap = await getDoc(dref);
          if (dsnap.exists()) {
            const det = dsnap.data();
            setClaseActual((prev) => ({
              ...(prev || {}),
              unidad: det.unidad ?? prev?.unidad ?? "(sin unidad)",
              objetivo: det.objetivo ?? prev?.objetivo ?? "(sin objetivo)",
              habilidades:
                det.habilidades ?? prev?.habilidades ?? "(sin habilidades)",
              asignatura:
                det.asignatura ??
                prev?.asignatura ??
                asignaturaProfe ??
                "(sin asignatura)",
            }));
          } else {
            // intentar leer la celda del horario
            try {
              const hcell = await getDoc(doc(db, "horarios", uid, "celdas", slotId));
              if (hcell.exists()) {
                const hx = hcell.data() || {};
                setClaseActual((prev) => ({
                  ...(prev || {}),
                  asignatura: hx.asignatura ?? prev?.asignatura ?? asignaturaProfe ?? "(sin asignatura)",
                  unidad: hx.unidad ?? prev?.unidad ?? "(sin unidad)",
                  objetivo: hx.objetivo ?? prev?.objetivo ?? "(sin objetivo)",
                  habilidades:
                    (Array.isArray(hx.habilidades) ? hx.habilidades.join(", ") : (hx.habilidades ?? "")) ||
                    prev?.habilidades ||
                    "(sin habilidades)",
                }));
              }
            } catch (e) {}
          }
        }
      } catch (e) {
        console.warn("[horarioConfig.marcas ÔåÆ clases_detalle]", e?.code || e?.message);
      }
    })();
  }, [authed, asignaturaProfe]);

  // clase actual + planificaci├│n sugerida
  useEffect(() => {
    if (!authed) return;
    (async () => {
      const uid = auth.currentUser?.uid || localStorage.getItem("uid");
      if (!uid) return;

      const matriz = await readHorarioMatrix(uid);
      if (!matriz) return;

      // Ô¼ç´©Å Fallbacks (se mantienen)
      const bloques = [
        "08:00 - 08:45",
        "08:45 - 09:30",
        "09:30 - 09:50 (Recreo)",
        "09:50 - 10:35",
        "10:35 - 11:20",
        "11:20 - 11:30 (Recreo)",
        "11:30 - 12:15",
        "12:15 - 13:00",
        "13:00 - 13:45 (Almuerzo)",
        "13:45 - 14:30",
        "14:30 - 15:15",
        "15:15 - 15:30 (Recreo)",
        "15:30 - 16:15",
        "16:15 - 17:00",
        "17:00 - 17:45",
        "17:45 - 18:30",
      ];
      const diasCorrectos = ["Lunes", "Martes", "Mi├®rcoles", "Jueves", "Viernes"];

      // Ô¼ç´©Å NUEVO: intento usar marcas desde horarioConfig; si no, dejo el fallback
      let marcas = [
        [8, 0],
        [8, 45],
        [9, 30],
        [9, 50],
        [10, 35],
        [11, 20],
        [11, 30],
        [12, 15],
        [13, 45],
        [14, 30],
        [15, 15],
        [15, 30],
        [16, 15],
        [17, 0],
        [17, 45],
        [18, 30],
      ];
      try {
        const uref = doc(db, "usuarios", uid);
        const usnap = await getDoc(uref);
        const cfg = usnap.exists() ? usnap.data().horarioConfig || {} : {};
        const m2 = getMarcasFromConfig(cfg);
        if (m2.length > 1) marcas = m2;                           // Ô¼à´©Å preferimos lo configurado
      } catch (e) {}

      const forcedSlot = slotFromQuery();
      let filaUsed = null;
      let colUsed = null;

      if (forcedSlot) {
        const [f, c] = forcedSlot.split("-").map((n) => Number(n));
        filaUsed = Number.isInteger(f) ? f : 0;
        colUsed = Number.isInteger(c) ? c : 0;
      } else {
        const now = FORCE_TEST_TIME ? getNowForSchedule() : nowFromQuery();
        const d = dowFromQuery() ?? now.getDay();
        const h = now.getHours(),
          m = now.getMinutes();

        let idx = marcas.findIndex(([hh, mm]) => h < hh || (h === hh && m < mm));
        if (idx === -1) idx = marcas.length - 1;
        else idx = Math.max(0, idx - 1);

        if (d >= 1 && d <= 5) {
          filaUsed = idx;
          colUsed = d - 1;
        } else {
          filaUsed = 0;
          colUsed = 0;
        }
      }

      if (
        filaUsed != null &&
        colUsed != null &&
        filaUsed >= 0 &&
        filaUsed < matriz.length &&
        colUsed >= 0 &&
        colUsed < (matriz[0]?.length || 5)
      ) {
        let found = null,
          foundIdx = filaUsed;

        // si no est├í forzado, busca la primera clase v├ílida hacia abajo
        if (!forcedSlot) {
          for (let k = filaUsed; k < matriz.length; k++) {
            const c = matriz[k][colUsed];
            if (c && (c.asignatura || c.nivel || c.seccion)) {
              found = c;
              foundIdx = k;
              break;
            }
          }
        } else {
          found = matriz[filaUsed][colUsed];
          foundIdx = filaUsed;
        }

        const clase = found;
        const slotIdCalc = slotIdFrom(foundIdx, colUsed);
        setCurrentSlotId(slotIdCalc);
        try { localStorage.setItem("__lastSlotId", slotIdCalc); } catch (e) {}

        if (clase?.asignatura) {
          const habilidadesTxt = Array.isArray(clase.habilidades)
            ? clase.habilidades.join(", ")
            : (clase.habilidades ?? "");
          setClaseActual({
            ...clase,
            unidad: clase.unidad ?? "(sin unidad)",
            objetivo: clase.objetivo ?? "(sin objetivo)",
            habilidades: habilidadesTxt ?? "(sin habilidades)",
            bloque: bloques[foundIdx],
            dia: diasCorrectos[colUsed],
            asignatura: clase.asignatura ?? asignaturaProfe ?? "(sin asignatura)",
          });

          try {
            const yearWeek = getYearWeek();
            const pref = doc(db, "planificaciones_sugeridas", uid, yearWeek, slotIdCalc);
            const ps = await getDoc(pref);
            setPlanSug(ps.exists() ? ps.data() : null);
          } catch (e) {
            console.warn("[planificaciones_sugeridas] read:", e?.code);
          }

          try {
            const detalleRef = doc(db, "clases_detalle", uid, "slots", slotIdCalc);
            const detalleSnap = await getDoc(detalleRef);

            if (detalleSnap.exists()) {
              const det = detalleSnap.data();
              setClaseActual((prev) => ({
                ...(prev || {}),
                unidad: det.unidad ?? prev?.unidad ?? "(sin unidad)",
                objetivo: det.objetivo ?? prev?.objetivo ?? "(sin objetivo)",
                habilidades:
                  det.habilidades ?? prev?.habilidades ?? "(sin habilidades)",
                asignatura:
                  det.asignatura ??
                  prev?.asignatura ??
                  asignaturaProfe ??
                  "(sin asignatura)",
              }));
            } else {
              // ­ƒåò NUEVO: si el detalle NO existe y la celda del horario trae campos,
              // los sembramos autom├íticamente en clases_detalle para que Inicio sea "directo".
              try {
                const payload = {
                  asignatura: clase.asignatura ?? "",
                  nivel: clase.nivel ?? "",
                  seccion: clase.seccion ?? "",
                  unidad: clase.unidad ?? "",
                  objetivo: clase.objetivo ?? "",
                  habilidades: habilidadesTxt ?? "",
                  updatedAt: serverTimestamp(),
                };
                const hasDetail = (payload.unidad || payload.objetivo || payload.habilidades);
                if (hasDetail) {
                  await setDoc(detalleRef, payload, { merge: true });
                } else {
                  // ├║ltimo intento: leer doc horarios/celdas/{slot}
                  try {
                    const hcell = await getDoc(doc(db, "horarios", uid, "celdas", slotIdCalc));
                    if (hcell.exists()) {
                      const hx = hcell.data() || {};
                      const p2 = {
                        asignatura: hx.asignatura ?? "",
                        nivel: hx.nivel ?? "",
                        seccion: hx.seccion ?? "",
                        unidad: hx.unidad ?? "",
                        objetivo: hx.objetivo ?? "",
                        habilidades: Array.isArray(hx.habilidades) ? hx.habilidades.join(", ") : (hx.habilidades ?? ""),
                        updatedAt: serverTimestamp(),
                      };
                      if (p2.unidad || p2.objetivo || p2.habilidades) {
                        await setDoc(detalleRef, p2, { merge: true });
                        setClaseActual((prev) => ({ ...(prev || {}), ...p2 }));
                      }
                    }
                  } catch (e) {}
                }
              } catch (e) {
                console.warn("[auto seed clases_detalle desde horario]", e?.code || e?.message);
              }
            }
          } catch (e) {
            console.warn("[clases_detalle] read:", e?.code);
          }
        }
      }
    })();
  }, [authed, asignaturaProfe]);

  // ========= NUEVO: escuchar palabras SOLO de la sala =========
  const [palabrasAgg, setPalabrasAgg] = useState([]); // [{text, value}]
  useEffect(() => {
    if (!salaCode) return; // a├║n no mont├│ sala
    const colRef = collection(db, "salas", salaCode, "palabras");
    let qRef = colRef;
    try {
      qRef = query(colRef, orderBy("timestamp"));
    } catch (e) {}
    const unsub = onSnapshot(
      qRef,
      (snap) => {
        const rows = snap
          .docs
          .map((d) => d.data())
          .filter((x) => (x.texto || "").trim().length > 0);

        // ├║ltimos env├¡os (los 5 m├ís recientes)
        const last = snap.docs
          .map((d) => ({
            id: d.id,
            ...d.data(),
            ts: d.data()?.timestamp?.toMillis?.() || 0,
          }))
          .sort((a, b) => b.ts - a.ts)
          .slice(0, 5);
        setUltimos(last);

        // agregaci├│n por palabra (lower + trim)
        const map = new Map();
        rows.forEach((x) => {
          const key = String(x.texto || "").trim().toLowerCase();
          if (!key) return;
          map.set(key, (map.get(key) || 0) + 1);
        });
        const agg = Array.from(map.entries()).map(([text, count]) => ({
          text,
          value: count,
        }));
        setPalabrasAgg(agg);

        try {
          window.__lastCloud = agg; // debug
          setTimeout(() => {
            setPalabrasAgg(
              (Array.isArray(agg) ? agg : []).map((x) => ({
                ...x,
                value: Number.isFinite(+x.value) ? +x.value : 1,
              }))
            );
          }, 0);
        } catch (e) {}
      },
      (e) => console.warn("[salas/palabras] onSnapshot:", e?.code || e?.message)
    );
    return () => unsub();
  }, [salaCode]);

  // guarda pregunta (debounce)
  const debounceRef = useRef(null);
  const onChangePregunta = (val) => {
    setPreguntaClase(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      try {
        await setDoc(
          doc(db, "preguntaClase", "actual"),
          { texto: val, updatedAt: serverTimestamp() },
          { merge: true }
        );
      } catch (e) {
        console.error("Error guardando pregunta:", e?.code);
      }
    }, 400);
  };

  // ====== WordCloud: tama├▒o segun frecuencia + colores ======
  const palette = [
    "#2563eb",
    "#16a34a",
    "#f59e0b",
    "#ef4444",
    "#a855f7",
    "#0ea5e9",
    "#10b981",
    "#f43f5e",
    "#f97316",
    "#84cc16",
  ];
  const fontSizeMapper = (w) => {
    const base = 18; // m├¡nimo
    const step = 10; // incremento por ocurrencia
    const max = 80; // tope
    return Math.min(max, base + (w.value - 1) * step);
  };
  const rotate = () => 0;
  const cloudData = useMemo(() => palabrasAgg, [palabrasAgg]);

  // === NUEVO: agrupar por palabra
  const cloudDataGrouped = useMemo(() => {
    const map = new Map();
    for (const w of palabras || []) {
      const key = (w.text || "").trim().toLowerCase();
      if (!key) continue;
      const v = Number(w.value || 1);
      map.set(key, (map.get(key) || 0) + (isFinite(v) ? v : 1));
    }
    return Array.from(map.entries()).map(([text, value]) => ({ text, value }));
  }, [palabras]);
  const maxValCloud = useMemo(
    () => cloudDataGrouped.reduce((m, w) => Math.max(m, Number(w.value || 0)), 1),
    [cloudDataGrouped]
  );
  const fontSizeMapper2 = (w) => {
    const v = Number(w.value || 0);
    const size = 16 + 44 * (v / (maxValCloud || 1)); // 16..60
    return Math.max(16, Math.min(60, Math.round(size)));
  };

  // ======== EXTRA: normaliza datos para react-d3-cloud ========
  const cloudDataForWC = useMemo(
    () =>
      (cloudData || []).map((w, i) => ({
        text: String(w.text || "").trim(),
        value: Number.isFinite(+w.value) && +w.value > 0 ? +w.value : 1,
        key: `${String(w.text || "").trim()}_${i}`,
      })),
    [cloudData]
  );

  // === NUEVO: tama├▒o responsive del SVG de la nube
  const cloudWrapRef = useRef(null);
  const [cloudSize, setCloudSize] = useState({ w: 800, h: 420 });
  useEffect(() => {
    const el = cloudWrapRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      const w = Math.max(320, Math.floor(entries[0].contentRect.width - 24));
      const h = Math.max(220, Math.floor(w * 0.52)); // proporci├│n agradable
      setCloudSize({ w, h });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // === NUEVO: decidir modo de nube autom├íticamente
  useEffect(() => {
    try {
      const stored = localStorage.getItem("cloudMode");
      if (!stored || stored === "auto") {
        const ok = supportsSvgTextBBox() && !isProblematicUA();
        const mode = ok ? "svg" : "html";
        localStorage.setItem("cloudMode", mode);
        setCloudMode(mode);
      } else {
        setCloudMode(stored);
      }
    } catch (e) {
      setCloudMode(supportsSvgTextBBox() && !isProblematicUA() ? "svg" : "html");
    }
  }, []);

  // Utilidad de seed (la mantengo como la ten├¡as)
  useEffect(() => {
    window.seedPruebaLunes = async () => {
      try {
        const uid = auth.currentUser?.uid || localStorage.getItem("uid");
        if (!uid) return alert("Sin uid");
        const slotId = "0-0";
        await setDoc(
          doc(db, "clases_detalle", uid, "slots", slotId),
          {
            unidad: "N├║meros y operaciones",
            objetivo: "Reconocer y aplicar propiedades de los n├║meros enteros.",
            habilidades:
              "Razonamiento y resoluci├│n de problemas; comunicaci├│n matem├ítica.",
            updatedAt: serverTimestamp(),
          },
          { merge: true }
        );
        alert("Ô£à Seed de detalle creado en clases_detalle/{uid}/slots/0-0");
      } catch (e) {
        console.error(e);
        alert("ÔØî No se pudo crear el seed de prueba");
      }
    };
  }, []);

  // ­ƒåò NUEVO: Auto-completar detalle desde curr├¡culo si hay codUnidad y faltan campos
  useEffect(() => {
    if (!authed || !currentSlotId) return;
    (async () => {
      try {
        const uid = auth.currentUser?.uid || localStorage.getItem("uid");
        if (!uid) return;

        const dref = doc(db, "clases_detalle", uid, "slots", currentSlotId);
        const dsnap = await getDoc(dref);
        const det = dsnap.exists() ? dsnap.data() : {};
        const needs =
          !(det?.unidad && String(det.unidad).trim()) ||
          !(det?.objetivo && String(det.objetivo).trim()) ||
          !(det?.habilidades && String(det.habilidades).trim());

        if (!needs) return;

        // Intentamos obtener un codUnidad de donde sea posible
        const cod =
          det?.codUnidad ||
          claseVigente?.codUnidad ||
          planSug?.codUnidad ||
          null;

        if (!cod) return; // sin c├│digo no podemos buscar curr├¡culo

        const curSnap = await getDoc(doc(db, "curriculo", cod));
        if (!curSnap.exists()) return;

        const c = curSnap.data();
        const payload = {
          codUnidad: cod,
          unidad: det.unidad ?? c.titulo ?? "Unidad",
          objetivo: det.objetivo ?? (Array.isArray(c.objetivos) ? c.objetivos[0] : "") ?? "",
          habilidades:
            det.habilidades ??
            (Array.isArray(c.habilidades) ? c.habilidades.join("; ") : "") ??
            "",
          updatedAt: serverTimestamp(),
        };

        await setDoc(dref, payload, { merge: true });
        setClaseActual((prev) => ({ ...(prev || {}), ...payload }));
      } catch (e) {
        console.warn("[autofill curriculo ÔåÆ clases_detalle]", e?.code || e?.message);
      }
    })();
  }, [authed, currentSlotId, claseVigente, planSug]);

  // Ô£à NUEVO: Si el objetivo est├í vac├¡o o "(sin objetivo)", intentar obtener el primer OA
  // usando curso ÔåÆ nivel (helper nivelDesdeCurso) + getPrimerOA
  useEffect(() => {
    if (!authed) return;

    const texto = String(claseActual?.objetivo || "").trim();
    const objetivoFaltante = !texto || /^\(sin/i.test(texto);

    if (!objetivoFaltante) return;

    (async () => {
      try {
        const asignatura =
          claseActual?.asignatura || asignaturaProfe || "";
        const curso = claseActual?.curso || claseVigente?.curso || "";
        const nivel =
          claseActual?.nivel ||
          nivelDesdeCurso(curso) ||
          claseVigente?.nivel ||
          "";

        const unidad = claseActual?.unidad || claseVigente?.unidad || "";
        if (!asignatura || !nivel || !unidad) return;

        // Si tu servicio admite (asignatura, nivel, codUnidad?, unidad?),
        // le pasamos codUnidad por si ayuda a resolver m├ís preciso:
        const primerOA = await getPrimerOA(
          asignatura,
          nivel,
          claseVigente?.codUnidad || null,
          unidad
        );

        if (!primerOA) return;

        // Actualiza estado
        setClaseActual((prev) => ({ ...(prev || {}), objetivo: primerOA }));

        // Persiste en el slot actual
        const uid = auth.currentUser?.uid || localStorage.getItem("uid");
        if (uid && currentSlotId) {
          await setDoc(
            doc(db, "clases_detalle", uid, "slots", currentSlotId),
            { objetivo: primerOA, updatedAt: serverTimestamp() },
            { merge: true }
          );
        }
      } catch (e) {
        console.warn("[getPrimerOA autofill]", e?.code || e?.message);
      }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    authed,
    currentSlotId,
    asignaturaProfe,
    claseVigente?.codUnidad,
    claseVigente?.unidad,
    claseVigente?.nivel,
    claseActual?.objetivo,
    claseActual?.curso,
    claseActual?.nivel,
    claseActual?.unidad,
    claseActual?.asignatura,
  ]);

  // Ôøæ´©Å NUEVO: modo seguro
  if (SAFE_MODE) {
    return (
      <div style={page}>
        <ICDebugBadge
          show={DEBUG_ON}
          data={{ SAFE_MODE, DISABLE_CLOUD, mounted: true }}
        />
        <div style={{ ...card, maxWidth: 960, margin: "20px auto" }}>
          Ô£à <b>InicioClase</b> mont├│ en <b>modo seguro</b>.<br />
          Quita <code>?safe=1</code> o usa <code>?nocloud=1</code> para aislar la
          nube si fuese necesario.
        </div>
      </div>
    );
  }

  /* ­ƒö╣­ƒö╣ NUEVO HELPER DE HABILIDADES (chips) ­ƒö╣­ƒö╣
     Normaliza desde claseActual.habilidades (string/array/objetos) o curriculo.habilidades */
  const habilidadesList = useMemo(() => {
    const raw =
      (claseActual?.habilidades ?? null) ??
      (curriculo?.habilidades ?? null);

    if (!raw) return [];

    // Array: strings u objetos { codigo, descripcion }
    if (Array.isArray(raw)) {
      return raw
        .map((x) =>
          typeof x === "string"
            ? x.trim()
            : x?.codigo
            ? x.descripcion
              ? `${x.codigo}: ${x.descripcion}`
              : x.codigo
            : x?.descripcion || ""
        )
        .filter(Boolean);
    }

    // String: "H1, H4" o texto con separadores
    if (typeof raw === "string") {
      return raw
        .split(/[,;ÔÇó\n]+/)
        .map((s) => s.trim())
        .filter(Boolean);
    }

    return [];
  }, [claseActual, curriculo]);

  return (
    <GlobalBoundary>
      <ICDebugBadge
        show={DEBUG_ON}
        data={{
          SAFE_MODE,
          DISABLE_CLOUD,
          authed,
          salaCode: salaCode || "(none)",
          cloudMode,
          palabras: (Array.isArray(cloudData) && cloudData.length) || 0,
        }}
      />

      <div style={page}>
        {/* ADICIONAL: Banner de clase vigente */}
        {claseVigente && (
          <div
            style={{
              ...card,
              marginBottom: "1rem",
              background:
                claseVigente.fuente === "calendario"
                  ? "rgba(124,58,237,.06)"
                  : "rgba(2,132,199,.06)",
            }}
          >
            <div style={{ fontWeight: 800 }}>
              {claseVigente.fuente === "calendario"
                ? "Plan semanal (vigente)"
                : claseVigente.fuente === "slots"
                ? "Horario (fallback)"
                : "Sin clase planificada"}
            </div>
            {claseVigente.fila != null && claseVigente.col != null && (
              <div style={{ fontSize: 13, color: "#475569" }}>
                Bloque #{claseVigente.fila} ┬À D├¡a #{claseVigente.col} (L=0)
              </div>
            )}
            {claseVigente.unidad && (
              <div style={{ marginTop: 6 }}>
                <b>Unidad:</b> {claseVigente.unidad}
                {claseVigente.evaluacion ? " ┬À (Evaluaci├│n)" : ""}
              </div>
            )}
            {(claseVigente.objetivo || claseVigente.habilidades) && (
              <div style={{ fontSize: 13, color: "#475569", marginTop: 4 }}>
                {claseVigente.objetivo && (
                  <span>
                    <b>Objetivo:</b> {claseVigente.objetivo} ┬À{" "}
                  </span>
                )}
                {claseVigente.habilidades && (
                  <span>
                    <b>Habilidades:</b> {claseVigente.habilidades}
                  </span>
                )}
              </div>
            )}
          </div>
        )}

        <div style={{ ...row("1rem"), marginBottom: "1rem" }}>
          <div style={{ ...card }}>
            <div style={{ fontWeight: 800, fontSize: "1.1rem", marginBottom: 6 }}>
              Inicio
            </div>
            <div style={{ color: COLORS.textMuted, marginBottom: 8 }}>
              ­ƒòÆ {horaActual}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: ".5rem" }}>
              <div style={{ fontSize: "1.6rem", fontWeight: 800 }}>
                {formatMMSS(remaining.m, remaining.s)}
              </div>
              <button onClick={resetCountdown} style={btnTiny} title="Reiniciar a 10:00">
                ­ƒöü
              </button>
            </div>
          </div>

          <div style={{ ...card }}>
            <div style={{ fontWeight: 800, fontSize: "1.2rem", marginBottom: 6 }}>
              Desarrollo de la clase
            </div>
            <div style={{ marginBottom: 6 }}>
              <strong>Unidad:</strong> {claseActual?.unidad ?? "(sin unidad)"}
            </div>
            <div style={{ marginBottom: 6 }}>
              <strong>Objetivo:</strong> {claseActual?.objetivo ?? "(sin objetivo)"}
            </div>
            <div>
              <strong>Habilidades:</strong>{" "}
              {claseActual?.habilidades ?? "(sin habilidades)"}
            </div>

            {/* ­ƒö╣ Chips visuales de habilidades (no reemplaza tu l├¡nea, la complementa) */}
            {habilidadesList.length > 0 && (
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 6,
                  marginTop: 6,
                }}
              >
                {habilidadesList.map((h, i) => (
                  <span
                    key={`${h}_${i}`}
                    style={{
                      border: "1px solid #cbd5e1",
                      background: "#f8fafc",
                      borderRadius: 999,
                      padding: "4px 10px",
                      fontSize: 12,
                    }}
                  >
                    {h}
                  </span>
                ))}
              </div>
            )}

            {planSug && (
              <div style={{ marginTop: 10 }}>
                <div>
                  <strong>Sugerencias del cat├ílogo:</strong>
                </div>
                {(planSug.fuentes?.length || 0) === 0 && (
                  <div style={{ color: COLORS.textMuted }}>
                    No hay sugerencias registradas.
                  </div>
                )}
                {planSug.fuentes?.length > 0 && (
                  <ul style={{ marginTop: 6 }}>
                    {planSug.fuentes.map((f, i) => (
                      <li key={i}>
                        {f.tipo ? <strong>{f.tipo}:</strong> : null}{" "}
                        {f.url ? (
                          <a href={f.url} target="_blank" rel="noreferrer">
                            {f.url}
                          </a>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                )}
                {planSug.programaUrl && (
                  <div style={{ marginTop: 6 }}>
                    <a href={planSug.programaUrl} target="_blank" rel="noreferrer">
                      Ver Programa de Estudio
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>

          <div style={{ ...card, display: "flex", flexDirection: "column", gap: ".6rem" }}>
            <div style={{ display: "flex", gap: ".5rem" }}>
              <button style={btnWhite}>Ô£ï</button>
              <button style={btnWhite}>­ƒæÅ</button>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontWeight: 800 }}>{nombre}</div>
              <div style={{ color: COLORS.textMuted }}>
                {claseActual?.asignatura ?? asignaturaProfe ?? "(sin asignatura)"}
              </div>
            </div>
          </div>
        </div>

        {/* ­ƒöÄ OA + Habilidades desde curriculo/{codUnidad} */}
        {cargandoCurriculo ? (
          <div style={{ ...card, marginBottom: "1rem", color: COLORS.textMuted }}>
            Cargando curr├¡culo MINEDUCÔÇª
          </div>
        ) : curriculo ? (
          <div style={{ ...card, marginBottom: "1rem" }}>
            <div style={{ fontWeight: 800, marginBottom: 6 }}>Objetivos de Aprendizaje</div>
            {curriculo.objetivos?.length ? (
              <ul style={{ marginTop: 6 }}>
                {curriculo.objetivos.map((oa, i) => (
                  <li key={i}>{oa}</li>
                ))}
              </ul>
            ) : (
              <div style={{ color: COLORS.textMuted }}>(Sin objetivos cargados)</div>
            )}
            <div style={{ fontWeight: 800, marginTop: 12, marginBottom: 6 }}>
              Habilidades
            </div>
            {curriculo.habilidades?.length ? (
              <ul style={{ marginTop: 6 }}>
                {curriculo.habilidades.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            ) : (
              <div style={{ color: COLORS.textMuted }}>(Sin habilidades cargadas)</div>
            )}
          </div>
        ) : (
          <div style={{ ...card, marginBottom: "1rem", color: COLORS.textMuted }}>
            No se encontr├│ informaci├│n curricular para esta unidad.
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "1rem" }}>
          <div style={card} ref={cloudWrapRef}>
            <h3 style={{ marginTop: 0, marginBottom: 8 }}>Ôÿü´©Å Nube de palabras</h3>

            {DISABLE_CLOUD ? (
              <div style={{ color: COLORS.textMuted, padding: "1rem 0" }}>
                (Nube desactivada con <code>?nocloud=1</code> para pruebas)
              </div>
            ) : (
              <>
                {cloudData.length === 0 ? (
                  <div style={{ color: COLORS.textMuted, padding: "1rem 0" }}>
                    A├║n no hay palabras. Pide a tus estudiantes que escaneen el QR y
                    env├¡en una palabra.
                  </div>
                ) : (
                  <div style={{ width: "100%", overflow: "hidden" }}>
                    {cloudMode === "html" ? (
                      <CanvasCloud
                        data={cloudDataForWC}
                        palette={palette}
                        width={cloudSize.w}
                        height={cloudSize.h}
                        fontSize={fontSizeMapper}
                      />
                    ) : (
                      <CloudBoundary
                        fallback={
                          <CanvasCloud
                            data={cloudDataForWC}
                            palette={palette}
                            width={cloudSize.w}
                            height={cloudSize.h}
                            fontSize={fontSizeMapper}
                          />
                        }
                      >
                        <WordCloud
                          data={cloudDataForWC}
                          font="Segoe UI, sans-serif"
                          fontSizeMapper={fontSizeMapper}
                          rotate={rotate}
                          padding={2}
                          width={cloudSize.w}
                          height={cloudSize.h}
                          fill={(w, i) => palette[i % palette.length]}
                          spiral="archimedean"
                        />
                      </CloudBoundary>
                    )}
                  </div>
                )}
              </>
            )}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <div
              style={{
                ...card,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              <h4 style={{ marginTop: 0 }}>­ƒô▓ Escanea para participar</h4>
              <div
                style={{
                  background: COLORS.white,
                  padding: 12,
                  borderRadius: 8,
                  border: `1px solid ${COLORS.border}`,
                }}
              >
                <QRCode value={participaURL || window.location.origin} size={200} />
              </div>
              <code style={{ fontSize: 12, marginTop: 8, color: COLORS.textMuted }}>
                {participaURL}
              </code>
              {salaCode && (
                <div style={{ marginTop: 8, fontWeight: 800 }}>
                  C├│digo: <span>{salaCode}</span>
                  <button
                    style={{ ...btnTiny, marginLeft: 8 }}
                    onClick={() => {
                      navigator.clipboard.writeText(participaURL);
                    }}
                  >
                    ­ƒôï Copiar
                  </button>
                </div>
              )}
            </div>

            <div style={card}>
              <h4 style={{ marginTop: 0 }}>­ƒòæ ├Ültimos env├¡os</h4>
              <ul style={{ margin: 0, paddingLeft: "1rem" }}>
                {ultimos.length === 0 && (
                  <li style={{ color: COLORS.textMuted }}>A├║n no hay respuestas</li>
                )}
                {ultimos.map((p) => (
                  <li key={p.id}>
                    #{p.numeroLista || "?"} ÔÇö {p.texto}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div style={{ ...card, marginTop: "1rem", textAlign: "center" }}>
          <em style={{ color: COLORS.textMuted }}>
            Espacio reservado para funciones futuras
          </em>
        </div>

        <div
          style={{
            marginTop: "1.25rem",
            textAlign: "center",
            display: "flex",
            gap: "0.75rem",
            justifyContent: "center",
          }}
        >
          
          <button
            onClick={() => {
              const key = makeCountKey(currentSlotId || "0-0");
              const endStr =
                localStorage.getItem(key) || localStorage.getItem(COUNT_KEY);
              const endMs = endStr ? Number(endStr) : 0;
              try { localStorage.setItem("__lastSlotId", currentSlotId || "0-0"); } catch (e) {}
              const ficha = makeFicha(); // Ô¼à´©Å NUEVO
              navigate("/desarrollo", {
                state: {
                  slotId: currentSlotId || "0-0",
                  endMs,
                  clase: claseActual || null,
                  ficha, // Ô¼à´©Å NUEVO
                },
              });
            }}
            style={btnWhite}
          >
            ÔÅ¡´©Å Ir a Desarrollo
          </button>
          <button onClick={() => navigate("/")} style={btnWhite}>
            Ô¼à´©Å Volver al Inicio
          </button>
        </div>
      </div>
    </GlobalBoundary>
  );
}

export default InicioClase;
// Compatibilidad: si en algún sitio quedó `import { InicioClase } ...`
export { InicioClase };
































































