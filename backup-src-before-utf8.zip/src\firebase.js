// src/firebase.js 
// (TEMP) comprueba que Vite está leyendo .env.local
console.log("API_KEY", import.meta.env.VITE_FIREBASE_API_KEY?.slice(0, 5), "…");

import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, setPersistence, browserLocalPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getFunctions, httpsCallable } from "firebase/functions";
import { getStorage } from "firebase/storage";
// 🔹 AÑADIDO: Analytics seguro
import { getAnalytics, isSupported } from "firebase/analytics";

// Lee variables desde .env.local (deben empezar con VITE_)
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
};

// Evita re-inicializar en HMR
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// 🔎 Logs de diagnóstico (enmascarados)
console.log("[FB] projectId:", firebaseConfig.projectId);
console.log("[FB] authDomain:", firebaseConfig.authDomain);
console.log("[FB] apiKey prefix:", (firebaseConfig.apiKey || "").slice(0, 6), "…");

// Auth con persistencia local (ignora si falla en algún entorno)
const auth = getAuth(app);
setPersistence(auth, browserLocalPersistence).catch(() => {});

// Servicios que usas en la app
const db = getFirestore(app);
// Si tu backend está en southamerica-east1, puedes fijar la región:
const functions = getFunctions(app, "southamerica-east1");
const storage = getStorage(app);
// Initialize Firebase

// ✅ Analytics protegido (sustituye la llamada directa para evitar crash)
let analytics;
try {
  if (firebaseConfig.measurementId) {
    isSupported().then((ok) => {
      if (ok) {
        analytics = getAnalytics(app);
        console.log("[FB] Analytics ON");
      } else {
        console.warn("[FB] Analytics no soportado en este entorno");
      }
    });
  } else {
    console.warn("[FB] Analytics omitido: falta measurementId");
  }
} catch (e) {
  console.warn("[FB] Analytics deshabilitado:", e?.message || e);
}

// Exporta para el resto de la app
export { app, auth, db, functions, storage };

/* ============================================================
   AÑADIDO: helper compatible con Pago.jsx
   - Llama al callable "flowCreateV2" y normaliza la respuesta a { url }
   - Si el callable falla (desarrollo/offline), devuelve un stub sandbox
   ============================================================ */
export async function callFlowCreateV2(payload) {
  try {
    const fn = getFunctions(app, "southamerica-east1");
    const crear = httpsCallable(fn, "flowCreateV2");
    const res = await crear(payload);
    const data = typeof res?.data === "string" ? { url: res.data } : (res?.data || {});
    // Normaliza posibles claves
    const url = data.url || data.paymentUrl || data.paymentURL || null;
    if (url) return { url };
    return data; // por si tu backend devuelve objeto con otras props útiles
  } catch (e) {
    console.warn("[firebase] callFlowCreateV2 fallback (stub):", e?.message || e);
    const token = `DUMMY-${Date.now()}`;
    return { url: `https://sandbox.flow.cl/app/web/pay.php?token=${encodeURIComponent(token)}` };
  }
}


