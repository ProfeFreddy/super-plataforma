import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

// Estas páginas ya existen en tu proyecto:
import CierreClase from "./pages/CierreClase.jsx";
import InicioClase from "./pages/InicioClase.jsx";
import HorarioEditable from "./pages/HorarioEditable.jsx";
import Pago from "./pages/Pago.jsx";
import DesarrolloClase from "./pages/DesarrolloClase";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/cierre" replace />} />
      <Route path="/cierre" element={<CierreClase />} />
      <Route path="/inicio" element={<InicioClase />} />
      <Route path="/desarrollo" element={<DesarrolloClase />} />
      <Route path="/horario" element={<HorarioEditable />} />
      <Route path="/pago" element={<Pago />} />
      <Route path="*" element={<div style={{padding:24}}>404 - Ruta no encontrada</div>} />
    </Routes>
  );
}

      
      

