// en src/services/Slots.js
export async function syncSlotsFromHorario(/* args */) {
  // ... implementación existente ...
}

